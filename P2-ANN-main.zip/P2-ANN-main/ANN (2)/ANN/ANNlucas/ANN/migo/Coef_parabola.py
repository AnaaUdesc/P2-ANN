import numpy as np
# import scipy as sp


def best_poly(x, y, k):
    n = len(x)
    if n <= k:
        raise ValueError(
            'O número de pontos deve ser maior que k (o grau do polinônmio)')

    somas = {}
    somas[0] = n
    for n in range(1, 2*k + 1):
        somas[n] = sum(xi ** n for xi in x)
    A = []
    B = []
    for i in range(k + 1):
        row = []
        for j in range(k + 1):
            row.append(somas[i + j])
        A.append(row)
        if i == 0:
            B.append(sum(y))
        else:
            B.append(sum(xi ** i * yi for xi, yi in zip(x, y)))
    return np.linalg.solve(A, B)


x = [0.3995, 0.97, 2.0343, 2.7567, 3.9472, 4.8679,
     5.1749, 6.0818, 7.238, 7.8686, 8.9499, 9.7128]
y = [4.9393, 4.6405, 4.1364, 3.7495, 3.3321, 3.2177,
     3.2578, 3.4545, 3.5728, 3.8718, 4.6922, 5.1904]
a0, a1, a2 = best_poly(x, y, 2)

print(f'{a0 = } , {a1 = }, {a2 = }')
