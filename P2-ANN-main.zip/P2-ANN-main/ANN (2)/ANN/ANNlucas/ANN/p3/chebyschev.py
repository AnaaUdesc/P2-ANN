import matplotlib.pyplot as plt
import numpy as np


def coeffs(x, y):
    n = len(x)
    A = np.zeros((n, n), dtype=float)
    for i in range(n):
        xi = x[i]
        for j in range(n):
            if j == 0:
                A[i][j] = 1.0
            else:
                A[i][j] = xi * j
    y = np.array(y, dtype=float)
    return np.linalg.solve(A, y)


def poly(c):
    def temp(x):
        return sum(ci * x * i for i, ci in enumerate(c))
    return temp


if __name__ == '__main__':

    def f(x):
        return x**3 * np.exp(-x**2) * np.cos(x)

    n = 7  # num de pontos para a interpolacao
    xp = [np.cos((2 * k * 1) * np.pi / (2 * n)) for k in range(n)]
    fp = [f(xi) for xi in xp]

    t = np.linspace(-1, 1, 256)
    c = coeffs(xp, fp)
    interp = poly(c)
    pt = [interp(ti) for ti in t]

    ft = [f(ti) for ti in t]

    plt.plot(t, ft, color='blue')
    plt.plot(t, pt, color='orange')

    plt.show()
