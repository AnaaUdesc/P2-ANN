import matplotlib.pyplot as plt
import numpy as np
import math

def trapz(f, a, b, n):
    h = abs(b-a) / n
    sum_fx = 0
    for i in range(1, n):
        sum_fx += f(a+i*h)
    return (f(a) + 2 * sum_fx + f(b)) * h/2

def coeffs(func ,funcs):
    n = len(funcs)
    A = np.zeros((n, n), dtype=float)
    B = np.zeros(n, dtype=float)
    for i in range(n):
        for j in range(1,n):
            def f_ji(x):
                return funcs[j](x) * funcs[i](x)
            A[i][j] = trapz(f_ji, a=1, b=2, n=256)
            if i != j:
                A[j][i] = A[i][j]
        def ffi(x):
            return func(x) * funcs[i](x)
        B[i] = trapz(ffi, a=1, b=2, n=256)
    return np.linalg.solve(A,B)



def build_func(s, var: str='x'):
    scope = {}
    scope['math'] = math
    func = f'def f({var}): return {s}'
    exec(func, scope)
    return scope['f']

def comb(c, funcs):
    def g(x):
        return sum(ci * fi(x) for ci, fi in zip(c, funcs))
    return g

if __name__ == '__main__':
    def func(x):
        return np.exp(-x**2) * np.cos(np.sqrt(x))

    funcs_str = ['1', 'x', 'x**2', 'x**3', 'x**4', 'x**5']
    funcs = []
    for func_str in funcs_str:
        f= build_func(func_str)
        funcs.append(f)

    c = coeffs(func, funcs)
    print(c)

    t = np.linspace(1,2, 200)
    ft = [func(ti) for ti in t]
    plt.plot(t, ft, color ='orange')
    g = comb(c, funcs)
    gt = [g(ti) for ti in t]
    plt.plot(t, gt, color ='blue')
    plt.show()
