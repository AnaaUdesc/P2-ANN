
import math


def quadratura(f, x, c):
    return sum([ci * f(xi) for ci, xi in zip(c, x)])


def change1(f, a, b):
    def g(u):
        return f((b + a) / 2 + u * (b - a) / 2) * (b - a) / 2
    return g


if __name__ == "__main__":

    def f_1(x):
        return 1 + 2 * x**4 - 3 * x**5 + 8 * x**7

    aprox_1 = quadratura(f_1, x, c)

    print(f'{aprox_1=}')
