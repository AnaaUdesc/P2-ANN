

def richardsonn(col_l):
    n = len(col_l)
    for i in range(n-1):
        for j in range(n-1-i):
            numer = 2 ** (i+1) * col_l[j+1] - col_l[j]
            denom = 2 ** (i+1) - 1
            value = numer / denom
            col_l[i] = value
    return col_l[0]


def main():

    def func(x):
        return x*x

    x0 = 2
    h = 0.1
    err_order = 4

    def F1(h):
        return (func(x0 + h) - func(x0)) / h

    col_F1 = [F1(h/2**i) for i in range(err_order)]

    aprox = richardsonn(col_F1)

    print(f'{aprox = }')


main()
