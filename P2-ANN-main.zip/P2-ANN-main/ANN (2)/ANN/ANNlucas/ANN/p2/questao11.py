import matplotlib.pyplot as plt
import numpy as np


def bestpoly(x, y, grau):
    k = grau + 1
    # A = np.zeros((k, k))
    A = [[0 for _ in range(k)] for _ in range(k)]
    B = [sum(y)]

    n = len(x)
    cache = {}
    for i in range(k):
        for j in range(k):
            p = i + j
            if p == 0:
                A[0][0] = n
                continue
            if p not in cache:
                cache[p] = sum([xi ** p for xi in x])
            A[i][j] = cache[p]
        if(i > 0):
            B.append(sum([yi * xi ** i for xi, yi in zip(x, y)]))

    return np.linalg.solve(A, B)


def poly(x, a, b):
    return np.exp((np.log(a) + b*x))


def build_func(a, b):
    def temp(x):
        return poly(x, a, b)
    return temp


def main():

    x = [0.0053, 0.2374, 0.475, 0.5943, 0.7422, 0.877,
         1.128, 1.2872, 1.4394, 1.6664, 1.7751, 1.9783]
    y = [3.7336, 5.5097, 8.3302, 9.4233, 12.8211, 15.7562,
         23.3201, 30.3166, 40.2952, 56.2558, 65.1611, 92.8711]
    values = [1.0066, 1.3637, 1.8125]
    print(f'{x = }')
    print(f'{y = }')
    grau = 1

    # transladar os pontos para cima
    k = abs(min(y)) + 1
    yt = [yi + k for yi in y]
    print(f'{y = }')

    y_ = np.log(yt)

    a0, a1 = bestpoly(x, y_, grau)

    a = np.exp(a0)
    b = a1

    print(f'{a0 = } e {a1 = }')

    p = build_func(a, b)

    def q(x):
        return p(x) - k

    plt.scatter(x, y)

    t = np.linspace(min(x), max(x), 200)
    qt = [q(ti) for ti in t]

    plt.plot(t, qt, color='r')
    plt.show()


main()
