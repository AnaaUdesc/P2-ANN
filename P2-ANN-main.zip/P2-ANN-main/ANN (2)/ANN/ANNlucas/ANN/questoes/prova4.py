import math


def richardson(col1):
    col1 = [item for item in col1]
    n = len(col1)
    for j in range(n - 1):
        temp_col = [0] * (n-1-j)
        for i in range(n - 1 - j):
            power = j + 1
            temp_col[i] = (2 ** power * col1[i+1] - col1[i]) / (2 ** power - 1)
        col1[:n - 1 - j] = temp_col
        print(temp_col)
    return col1[0]


def func(x):
    return x**2 * math.tan(math.sin(x/math.pi))


if __name__ == '__main__':

    # h = 0.46886
    # x0 = 1.4274
    # orders = [4, 5, 6, 7, 8]
    # err_order = 8

    h = 0.35307
    x0 = 1.28686
    orders = [2, 3, 4, 5, 6]
    err_order = 6

    def F1(f, x0, h):
        return (func(x0 + h) - func(x0)) / h

    col_F1 = [F1(func, x0, h/2**i) for i in range(err_order)]

    aprox = richardson(col_F1)

    print(f'{aprox = }')
