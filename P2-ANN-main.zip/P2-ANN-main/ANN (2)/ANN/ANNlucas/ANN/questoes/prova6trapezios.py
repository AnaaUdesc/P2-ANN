x = [0.0,
     5.0,
     10.0,
     15.0,
     20.0,
     25.0,
     30.0,
     35.0,
     40.0,
     45.0,
     50.0,
     55.0,
     60.0]

y = [110.91,
     140.27,
     274.88,
     232.86,
     121.34,
     202.23,
     156.49,
     213.3,
     291.06,
     164.43,
     261.29,
     181.12,
     245.9]
soma = 0
xy = zip(x, y)

for a2, b2 in zip(x[1:], y[1:]):  # lista de x e y removidos os primeiros elementos
    for a1, b1 in zip(x, y):
        soma += ((a2-a1) * (b2 + b1))/2.0
        x.pop(0)  # removendo os primeiros elementos das listas de x e y
        y.pop(0)
        break

print('soma de verdade?', soma)
