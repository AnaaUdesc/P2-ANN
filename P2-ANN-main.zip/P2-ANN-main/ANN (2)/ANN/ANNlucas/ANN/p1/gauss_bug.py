import math


def print_matrix(e):
    for i in range(len(e)):
        for j in range(len(e[i])):
            print(e[i][j], end='\t')
        print()


def gau(e):
    for j in range(len(e) - 2):
        for i in range(j, len(e[j])):
            if(e[i][j] != 0):
                if(i != j):
                    for k in range(len(e)):
                        temp = e[i][k]
                        e[i][k] = e[j][k]
                        e[j][k] = temp
                for m in range(j+1, len(e)):
                    a = -e[m][j] / e[j][j]
                    for n in range(j, len(e[m])):
                        e[m][n] = a * e[j][n] + e[m][n]
                print_matrix(e)
                print()
                break


def reversesub(e):
    d = len(e) - 1
    temp = [x for x in e]
    for i in range(len(e)):
        j = d - i
        soma = e[j][len(e[i]) - 1]
        for k in range(j+1, len(e[i])):
            soma -= e[j][k] * temp[k]
        soma /= e[j][j]
        print('x^%d = %.16f' % (j, soma))
        temp[j] = soma


def main():

    e = [
        [2,  4,  6,  2,  4],
        [1,  2, -1,  3,  8],
        [-3, 1, -2,  1, -2],

    ]

    print_matrix(e)
    print()
    gau(e)
    # reversesub(e)


main()
