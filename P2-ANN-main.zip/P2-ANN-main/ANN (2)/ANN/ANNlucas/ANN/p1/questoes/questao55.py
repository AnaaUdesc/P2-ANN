import matplotlib.pyplot as plt
import numpy as np


def lagrange(x, y):
    # retorna yi dividido pelo denominador do polinomio Li
    num = len(x)
    coefs = []
    for i in range(num):
        prod = 1
        for j in range(num):
            if i != j:
                prod *= (x[i] - x[j])
        ci = y[i]/prod
        coefs.append(ci)
    return coefs


def pl(t, x, coefs):
    soma = 0
    num = len(coefs)
    for i in range(num):
        prod = 1
        for j in range(num):
            if i != j:
                prod *= (t-x[j])
        prod *= coefs[i]
        soma += prod
    return soma


def poly(x, coefs):
    def f(t):
        return pl(t, x, coefs)
    return f


# def f(x):
#     return 1/(1 + 25*(x**2))

def f(x):
    return np.cos(np.sin(np.log(x**2)))


if __name__ == '__main__':
    x = [0.437, 0.84, 1.324, 1.474, 1.914, 2.255, 2.855]
    y = []

    for i in x:
        y.append(f(i))

    c = lagrange(x, y)
    print(c)
    lagr = poly(x, c)
    # print(lagrange(x, y))
    print(lagr(0))

    np.set_printoptions(suppress=True)
    plt.scatter(x, y)
    t = np.linspace(min(x), max(x), 100)
    lt = [lagr(ti) for ti in t]
    plt.plot(t, lt)
    plt.show()
