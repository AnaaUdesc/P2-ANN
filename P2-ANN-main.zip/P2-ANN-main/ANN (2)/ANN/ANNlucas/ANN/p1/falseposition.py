import math

n = 178205624
lam = 1.41*pow(10, -10)


def f(t):
    return ((n+1) / (1 + (n*math.exp(-lam*(n+1)*t)))) - n/4


def false_position(a, b, n):
    fa = f(a)
    fb = f(b)
    if(fa * fb >= 0):
        print(
            'O teorema de bolzano nao sabe dizer se existe raiz para f no intervalo [%.16f, %.16f]' % (a, b))
        return
    else:
        for i in range(n):
            x = (a * fb - b * fa) / (fb - fa)
            print("x_%d = %.16f" % (i+1, x))
            fx = f(x)
            if(fx == 0):
                print('encontramos uma raiz para f, ela eh = %.16f' % (x))
                return
            if(fa * fx < 0):
                b = x
                fb = fx
            else:
                a = x
                fa = fx


def main():
    a = 0
    b = 1513
    n = 11

    false_position(a, b, n)


main()
