from methods import *

x0 = 2.30239
approximations = [-0.39944983397183575, -0.37469506677440645, -0.36156732928997215, -0.354838917484944]

new_value = richardson(approximations.copy())
print(new_value)
