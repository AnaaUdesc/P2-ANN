from math import *
import numpy as np


# Métodos de integração (necessários para solução do sistema de equações):
def trapz(f, a, b, n):
    h = (b - a) / n
    soma = 0
    for k in range(1, n):
        soma += (f(a +  k * h))
    soma *= 2
    soma += (f(a) + f(b))
    return soma * (h / 2)


def aprox_coeffs(func_list, f, a, b, n):
    A = []
    B = []
    # Obs.: note que a matriz A é simétrica portanto não precisamos calcular n² integrais
    for i, fi in enumerate(func_list):
        row = []
        b_i = trapz(lambda x: f(x)*fi(x), a, b, n)
        for j, fj in enumerate(func_list):
            """
            Note que:
            (1) a_ij = ∫ fj(x)*fi(x) dx;
            (2) visto que a matriz A é simétrica e a parte acima da diagonal é calculada primeiro,
            não é necessário calcular os elementos em que i > j.
            """
            if(i <= j):
                a_ij = trapz(lambda x: fi(x)*fj(x), a, b, n)
                row.append(a_ij)
            else:
                row.append(A[j][i])
                
        B.append(b_i)
        A.append(row)
    return np.linalg.solve(A, B)

"""
Observe que são calculadas n integrais na diagonal + [(n-1) + (n-2) + ... + 2 + 1] integrais das diagonais acima + n integras das integrais
na matriz B, o que resulta em n(n+1)/2 + n = (n² + 3n)/2 integrais, o que é mesmo assim uma valor O(n²) apesar da otimização em relação aos
elementos iguais (pela simetria da matriz).
"""

def aprox_coeffs_ort(func_list, f, a, b, n):
    coeffs = []
    for fi in func_list:
        ck = trapz(lambda x: f(x)*fi(x), a, b, n)/trapz(lambda x: fi(x)*fi(x), a, b, n)
        coeffs.append(ck)
    return coeffs

"""
Observe que nesta outra função, dado que estamos considerando que 'func_list' é uma lista de funções duas à duas ortogonais, precisamos apenas
calcular os n elementos da diagonal da matriz A + os n elementos da matriz coluna B, assim temos que calcular 2n integrais apenas, e portanto,
agora temos um problema de complexidade O(n).
"""

def build_aprox_func(func_list, coeffs):
    def g(x):
        return sum(ck*fk(x) for ck, fk in zip(coeffs, func_list))
    return g

# Função que retorna o produto escalar entre duas funções f(x) e g(x):
def prod_esc(f, g, a, b, n):
    return trapz(lambda x: f(x)*g(x), a, b, n)

# Função que retorna o resultado da projeção de f(x) em g(x):
def proj(f, g, a, b, n):
    def proj(x):
        return (prod_esc(f, g, a, b, n)/prod_esc(g, g, a, b, n))*g(x)
    return proj

# Função que retorna o resultado a constante k da projeção de f(x) em g(x):
def proj_k(f, g, a, b, n) -> float:
    return (prod_esc(f, g, a, b, n)/prod_esc(g, g, a, b, n))

# Função para ortogonalizar uma lista de funções (Gran Schimidt):
def ortog_funcs(func_list, a, b, n):
    G = [func_list[0]]
    for fi in func_list[1:]:
        def gi(x):
            sum = 0
            for gj in G:
                sum -= proj_k(fi, gj, a, b, n)*gj(x)
            return fi(x) + sum
        G.append(gi)
    return G
# Obs.: essa função resulta em erro de recursão.

if __name__ == '__main__':
    
    # Exemplo 01:
    a = -1.43182
    b= 1.11208
    n = 500

    def f1(x): return 1
    def f2(x): return x
    def f3(x): return x**2
    def f4(x): return x**3
    def f5(x): return x**4
    def f6(x): return x**5
    def f7(x): return x**6
    def f8(x): return x**7
    def f9(x): return x**8
    def f10(x): return x**9

    def g1(x): return f1(x)

    a_21 =  proj_k(f2, g1, a, b, n)
    def g2(x): return f2(x) - a_21*g1(x)
    
    a_31 = proj_k(f3, g1, a, b, n)
    a_32 = proj_k(f3, g2, a, b, n)
    def g3(x): return f3(x) - a_31*g1(x) - a_32*g2(x)
    
    a_41 = proj_k(f4, g1, a, b, n)
    a_42 = proj_k(f4, g2, a, b, n)
    a_43 = proj_k(f4, g3, a, b, n)
    def g4(x): return f4(x) - a_41*g1(x) - a_42*g2(x) - a_43*g3(x)

    a_51 = proj_k(f5, g1, a, b, n)
    a_52 = proj_k(f5, g2, a, b, n)
    a_53 = proj_k(f5, g3, a, b, n)
    a_54 = proj_k(f5, g4, a, b, n)
    def g5(x): return f5(x) - a_51*g1(x) - a_52*g2(x) - a_53*g3(x) - a_54*g4(x)

    a_61 = proj_k(f6, g1, a, b, n)
    a_62 = proj_k(f6, g2, a, b, n)
    a_63 = proj_k(f6, g3, a, b, n)
    a_64 = proj_k(f6, g4, a, b, n)
    a_65 = proj_k(f6, g4, a, b, n)
    def g6(x): return f6(x) - a_61*g1(x) - a_62*g2(x) - a_63*g3(x) - a_64*g4(x)- a_65*g5(x)

    a_71 = proj_k(f7, g1, a, b, n)
    a_72 = proj_k(f7, g2, a, b, n)
    a_73 = proj_k(f7, g3, a, b, n)
    a_74 = proj_k(f7, g4, a, b, n)
    a_75 = proj_k(f7, g4, a, b, n)
    a_76 = proj_k(f7, g4, a, b, n)
    def g7(x): return f7(x) - a_71*g1(x) - a_72*g2(x) - a_73*g3(x) - a_74*g4(x)- a_75*g5(x) - a_76*g6(x)

    a_81 = proj_k(f8, g1, a, b, n)
    a_82 = proj_k(f8, g2, a, b, n)
    a_83 = proj_k(f8, g3, a, b, n)
    a_84 = proj_k(f8, g4, a, b, n)
    a_85 = proj_k(f8, g4, a, b, n)
    a_86 = proj_k(f8, g4, a, b, n)
    a_87 = proj_k(f8, g4, a, b, n)
    def g8(x): return f8(x) - a_81*g1(x) - a_82*g2(x) - a_83*g3(x) - a_84*g4(x)- a_85*g5(x) - a_86*g6(x)- a_87*g7(x)

    a_91 = proj_k(f9, g1, a, b, n)
    a_92 = proj_k(f9, g2, a, b, n)
    a_93 = proj_k(f9, g3, a, b, n)
    a_94 = proj_k(f9, g4, a, b, n)
    a_95 = proj_k(f9, g4, a, b, n)
    a_96 = proj_k(f9, g4, a, b, n)
    a_97 = proj_k(f9, g4, a, b, n)
    a_98 = proj_k(f9, g4, a, b, n)
    def g9(x): return f9(x) - a_91*g1(x) - a_92*g2(x) - a_93*g3(x) - a_94*g4(x)- a_95*g5(x) - a_96*g6(x)- a_97*g7(x)- a_98*g8(x)

    a_101 = proj_k(f10, g1, a, b, n)
    a_102 = proj_k(f10, g2, a, b, n)
    a_103 = proj_k(f10, g3, a, b, n)
    a_104 = proj_k(f10, g4, a, b, n)
    a_105 = proj_k(f10, g4, a, b, n)
    a_106 = proj_k(f10, g4, a, b, n)
    a_107 = proj_k(f10, g4, a, b, n)
    a_108 = proj_k(f10, g4, a, b, n)
    a_109 = proj_k(f10, g4, a, b, n)
    def g10(x): return f10(x) - a_101*g1(x) - a_102*g2(x) - a_103*g3(x) - a_104*g4(x)- a_105*g5(x) - a_106*g6(x)- a_107*g7(x)- a_108*g8(x)- a_109*g9(x)


    func_list = [g1, g2, g3, g4,g5,g6,g7,g8,g9]
    
    print(a_21, end=',\n')

    print(a_31, end=',\n')
    print(a_32, end=',\n')

    print(a_41, end=',\n')
    print(a_42, end=',\n')
    print(a_43, end=',\n')

    print(a_51, end=',\n')
    print(a_52, end=',\n')
    print(a_53, end=',\n')
    print(a_54, end=',\n')

    print(a_61, end=',\n')
    print(a_62, end=',\n')
    print(a_63, end=',\n')
    print(a_64, end=',\n')
    print(a_65, end=',\n')

    print(a_71, end=',\n')
    print(a_72, end=',\n')
    print(a_73, end=',\n')
    print(a_74, end=',\n')
    print(a_75, end=',\n')
    print(a_76, end=',\n')
    
    print(a_81, end=',\n')
    print(a_82, end=',\n')
    print(a_83, end=',\n')
    print(a_84, end=',\n')
    print(a_85, end=',\n')
    print(a_86, end=',\n')
    print(a_87, end=',\n')

    print(a_91, end=',\n')
    print(a_92, end=',\n')
    print(a_93, end=',\n')
    print(a_94, end=',\n')
    print(a_95, end=',\n')
    print(a_96, end=',\n')
    print(a_97, end=',\n')
    print(a_98, end=',\n')

    print(a_101, end=',\n')
    print(a_102, end=',\n')
    print(a_103, end=',\n')
    print(a_104, end=',\n')
    print(a_105, end=',\n')
    print(a_106, end=',\n')
    print(a_107, end=',\n')
    print(a_108, end=',\n')
    print(a_109, end=',\n')

    # Função para aproximar g(x):
    def f(x): 
        if x >= 0:
            return 2
        return -2
    
    
    coeffs = aprox_coeffs_ort(func_list, f, a, b, n)
    g = build_aprox_func(func_list, coeffs)
    print(coeffs)
