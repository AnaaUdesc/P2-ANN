import numpy as np
# import scipy as sp

def best_poly (x, y, k):
    n = len(x)
    if n <= k:
        raise ValueError('O número de pontos deve ser maior que k (o grau do polinônmio)')

    somas = {}
    somas[0] = n
    for n in range(1, 2*k + 1):
        somas[n] = sum(xi ** n for xi in x)
    A = []
    B = []
    for i in range (k + 1):
        row = []
        for j in range(k + 1):
            row.append(somas[i + j])
        A.append(row)
        if i == 0:
            B.append(sum(y))
        else:
            B.append(sum(xi ** i * yi for xi, yi in zip(x,y)))
    return np.linalg.solve(A, B)

x = [-4.466, -3.6123, -3.2483, -2.6883, -1.9385, -1.4692, -0.8965, -0.3965, 0.4717, 0.9847, 1.3514, 2.0555, 2.4452, 3.144, 3.788, 3.9709]
y =  [-7.0626, 2.434, 3.1176, 3.8729, 0.0203, -1.1646, -1.7586, -0.6372, 0.599, 0.4653, 1.3079, -1.7431, -1.17, -2.7026, -1.619, -0.2426]

a0, a1, a2, a3, a4, a5 = best_poly(x, y, 5)

print(f'{a0} , {a1}, {a2}, {a3}, {a4}, {a5},')


values =   [-3.2686, -0.0347, 0.5177]

for i in values:
    y = a0 + a1* i + a2* i**2 + a3 * i**3 + a4 * i**4 + a5 * i**5
    print(f"{y}, ")