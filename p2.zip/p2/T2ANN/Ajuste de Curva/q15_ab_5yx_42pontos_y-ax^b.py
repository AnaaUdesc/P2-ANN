import numpy as np
'''
Encontre os coeficientes a e b da função potência y=ax^b que melhor se aproxima da seguinte lista de 12 pontos
(0.6168,1.2651)...
'''

def best_poly(x, y, grau=1):
    k = grau + 1
    A = [[0 for _ in range(k)] for _ in range(k)]
    B = [sum(y)]
    n = len(x)
    cache = {}
    for i in range(k):
        for j in range(k):
            p = i + j
            if p == 0:
                A[0][0] = n
                continue
            if p not in cache:
                cache[p] = sum([xi**p for xi in x])
            A[i][j] = cache[p]
        if i > 0:
            B.append(sum([yi*xi**i for xi, yi in zip(x, y)]))
    return np.linalg.solve(A, B)


def poly(x, a, b):
    return a*x**b


def build_func(a, b):
    def temp(x):
        return poly(x, a, b)
    return temp


if __name__ == '__main__':
    x = [0.5531, 0.5938, 0.6507, 0.7053, 0.7739, 0.7983, 0.8887, 0.9556, 1.0193, 1.0739, 1.1337, 1.1892, 1.2352, 1.2888, 1.3563, 1.443, 1.4614, 1.5687, 1.6029, 1.6427, 1.7033, 1.7939, 1.8528, 1.9192, 1.9337, 2.0392, 2.0631, 2.1096, 2.1957, 2.2633, 2.3281, 2.395, 2.4622, 2.4764, 2.5478, 2.6115, 2.6488, 2.7241, 2.7667, 2.871, 2.8909, 2.9487]
    y =  [0.2259, 0.3018, 0.7724, 0.4054, 0.7725, 0.8119, 0.9609, 0.0352, 0.7851, 1.098, 1.5835, 0.7983, 1.9129, 1.4063, 3.1644, 2.3237, 3.3263, 5.2201, 4.6837, 5.5587, 6.7514, 6.5474, 8.2629, 8.7819, 9.2659, 11.1628, 11.4746, 12.2285, 14.2504, 15.9875, 17.276, 18.0568, 20.7944, 20.434, 23.3876, 26.2889, 26.885, 29.6903, 31.8366, 35.6606, 37.6649, 39.7989]
    values =  [0.6784, 0.7783, 0.9348, 2.1197, 2.3064]
    if min(y) <= 0:
        k1 = abs(min(y)) + 1
    else:
        k1 = 0

    if min(x) <= 0:
        k2 = abs(min(x)) + 1
    else:
        k2 = 0

    yt = [yi + k1 for yi in y]

    y_ = np.log(yt)

    xt = [xi + k2 for xi in x]

    x_ = np.log(xt)

    grau = 1

    a0, a1 = best_poly(x_, y_, grau)

    a = np.exp(a0)

    b = a1

    #pltprint('Coeficientes da reta')
   # print(f'{a0 = } e {a1 = }')

   # print('Coeficientes da potencia')
    print(f'{a = } e {b = }')

    p = build_func(a, b)

    def q(x):
        return p(x+k2) - k1

    for value in values:
        print(f'{q(value)}, ')

    # visualização

   # import matplotlib.pyplot as plt

   # plt.scatter(x, y)

    #t = np.linspace(min(x), max(x), 200)
    #qt = [q(ti) for ti in t]

    #plt.plot(t, qt)

    #plt.savefig('best_poly_regressao_potencia.png')