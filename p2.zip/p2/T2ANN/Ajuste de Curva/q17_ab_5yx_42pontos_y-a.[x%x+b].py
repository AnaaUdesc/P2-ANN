import numpy as np
import math


'''
Encontre os coeficientes a e b da função taxa de crescimento da saturação y=a(x/(x+b) que melhor se aproxima da seguinte lista de 12 pontos
(2.106,0.8735)...
'''

def best_line(x, y, grau=1):
    n = len(x)
    # soma das coordenadas x
    sum_x = sum(x)
    # soma das coordenadas x**2
    sum_x2 = sum(xi ** 2 for xi in x)
    # soma das coordenadas y
    sum_y = sum(y)
    #soma das coordenadas x*y
    sum_xy = sum(xi * yi for xi, yi in zip(x, y))

    # Matriz dos coeficientes
    A = [[n, sum_x], [sum_x, sum_x2]]
    # Matriz dos termos independentes
    B = [sum_y, sum_xy]

    return np.linalg.solve(A, B)

def poly(x, a, b):
    return a * (x/(x+b))
    # funcaomath.pow(x,b)

def build_func(a, b):
    def temp(x):
        return poly(x, a, b)
    return temp

if __name__ == '__main__':
    x = [1.0943, 1.6574, 2.0712, 2.6124, 3.2539, 3.2781, 3.7283, 4.2903, 4.9957, 5.3786, 5.5535, 6.4212, 6.7648, 7.0838, 7.5434, 7.8561, 8.4351, 8.7033, 9.335, 9.894, 10.4067, 10.6427, 11.2471, 11.8561, 12.1923, 12.6419, 12.8683, 13.456, 13.7807, 14.1485, 14.9097, 15.1872, 15.8838, 16.3294, 16.8181, 17.2733, 17.6796, 18.0428, 18.3381, 18.6536, 19.2105, 19.9893]
    y = [0.4163, 0.5903, 0.6931, 0.8083, 0.8977, 0.9225, 0.9581, 1.0599, 1.1267, 1.1552, 1.1987, 1.2362, 1.2728, 1.2801, 1.3268, 1.3691, 1.3635, 1.4028, 1.4502, 1.4564, 1.4889, 1.5001, 1.5164, 1.5186, 1.5457, 1.5583, 1.5919, 1.6198, 1.5818, 1.578, 1.6099, 1.6851, 1.6511, 1.6387, 1.6038, 1.6831, 1.6841, 1.6584, 1.6811, 1.699, 1.6497, 1.7248]
    values = [3.341, 7.6071, 9.816, 10.8425, 13.9194]
    if min(y) <= 0:
        k1 = abs(min(y)) + 1
    else:
        k1 = 0

    if min(x) <= 0:
        k2 = abs(min(x)) + 1
    else:
        k2 = 0

    yt = [yi + k1 for yi in y]

    y_ = (np.divide(1,y))

    xt = [xi + k2 for xi in x]

    x_ = np.divide(1,x)
    grau = 1

    a0, a1 = best_line(x_, y_, grau)

    a = 1/a0

    b = a1/a0
    print('Coeficientes da reta')
    print(f'{a0 = } e {a1 = }')

    print('Coeficientes')
    print(f'{a = } e {b = }')

    p = build_func(a, b)

    def q(x):
        return p(x+k2) - k1

    px = [p(vi) for vi in values]
    print(f'{px = }')

    # visualização

''' import matplotlib.pyplot as plt

    plt.scatter(x, y)

    t = np.linspace(min(x), max(x), 200)
    qt = [q(ti) for ti in t]

    plt.plot(t, qt)

    plt.savefig('best_poly_regressao_potencia.png')
    '''