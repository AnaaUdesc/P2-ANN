import numpy as np

#a*2^(bx)

def best_poly(x, y, grau = 1):
    k = grau + 1
    A = [[0 for _ in range(k)] for _ in range(k)]
    B = [sum(y)]
    n = len(x)
    cache = {}
    for i in range(k):
        for j in range(k):
            p = i + j
            if (p == 0):
                A[0][0] = n
                continue
            if p not in cache:
                cache[p] = sum([xi ** p for xi in x])
            A[i][j] = cache[p]
        if i > 0:
            B.append(sum([yi * xi ** i for xi, yi in zip(x, y)]))
    return np.linalg.solve(A, B)

def poly(x, a, b):
    return a * 2 ** (b * x)

def build_func(a, b):
    def temp(x):
        return poly(x, a, b)
    return temp

if __name__ == '__main__':
    x = [0.1423, 0.2246, 0.4559, 0.5552, 0.7179, 0.9058, 1.1277, 1.2117, 1.3573, 1.5949, 1.7567, 1.8487]
    y = [4.5047, 6.6617, 8.8877, 11.088, 14.137, 21.6937, 27.8767, 31.822, 40.3253, 60.0038, 79.2836, 91.6215]
    values =  [0.4022, 0.4304, 1.7244]
    y_ = np.log(y)
 
    grau = 1

    a0, a1 =  best_poly(x, y_, grau)

   # print(f'{a0 = } e {a1 = }')

    a = np.exp(a0)
    b = a1

    print(f'{a = } e {b = }')

    p = build_func(a, b/np.log(2))


    
    for xi_v in values:
        print(f'{p(xi_v)}, ')