import numpy as np

def best_line(x, y):
    n = len(x)
    # soma das coordenadas x
    sum_x = sum(x)
    # soma das coordenadas x**2
    sum_x2 = sum(xi ** 2 for xi in x)
    sum_x3 = sum(xi ** 3 for xi in x)
    sum_x4 = sum(xi ** 4 for xi in x)
    # soma das coordenadas y
    sum_y = sum(y)
    #soma das coordenadas x*y
    sum_xy = sum(xi * yi for xi, yi in zip(x, y))
    sum_yx2 = sum(xi**2 * yi for xi, yi in zip(x, y))


    # Matriz dos coeficientes
    A = [[n, sum_x,sum_x2], [sum_x, sum_x2,sum_x3],[sum_x2,sum_x3,sum_x4]]
    # Matriz dos termos independentes
    B = [sum_y, sum_xy,sum_yx2]

    print(A)
    print(B)

    return np.linalg.solve(A, B)

# exemplo:
x = [0.402, 1.2429, 2.1868, 2.6444, 3.6377, 4.9169, 5.0006, 6.1523, 7.4999, 7.9941, 8.3373, 9.262]

y = [5.997, 5.3901, 4.8536, 4.606, 4.4322, 4.0357, 3.7541, 3.9313, 4.104, 4.3917, 4.774, 4.8519]

a0, a1, a2 = best_line(x, y)


x1= a0 + a1 * 4.6468+ a2*(4.6468**2)
x2= a0 + a1 *  5.7541 + a2*( 5.7541**2)
x3= a0 + a1 * 7.0967 + a2*(7.0967**2)


print(x1, x2, x3, )

