import numpy as np
# import scipy as sp

def best_poly (x, y, k):
    n = len(x)
    if n <= k:
        raise ValueError('O número de pontos deve ser maior que k (o grau do polinônmio)')

    somas = {}
    somas[0] = n
    for n in range(1, 2*k + 1):
        somas[n] = sum(xi ** n for xi in x)
    A = []
    B = []
    for i in range (k + 1):
        row = []
        for j in range(k + 1):
            row.append(somas[i + j])
        A.append(row)
        if i == 0:
            B.append(sum(y))
        else:
            B.append(sum(xi ** i * yi for xi, yi in zip(x,y)))
    return np.linalg.solve(A, B)

x = [-4.4202, -3.9745, -2.8472, -2.6741, -1.7312, -0.8214, -0.2754, 0.1459, 1.1006, 2.3268, 2.719, 3.725, 4.2588, 5.1353, 5.3627]
y =[-2.4543, -0.0877, 2.462, 2.2876, 0.8839, -0.8541, -0.7559, 0.0435, 0.5429, 2.052, 3.1646, 4.5521, 3.5028, -1.0286, -3.6639]

a0, a1, a2, a3, a4 = best_poly(x, y, 4)

print(f'{a0} , {a1}, {a2}, {a3}, {a4},') 

values =  [-2.9237, -2.4489, 1.6092]

for i in values:
    y = a0 + a1* i + a2* i**2 + a3 * i**3 + a4 * i**4
    print(f"{y}, ")
