import numpy as np
# import scipy as sp


def best_poly(x, y, k):
    n = len(x)
    if n <= k:
        raise ValueError(
            'O número de pontos deve ser maior que k (o grau do polinônmio)')

    somas = {}
    somas[0] = n
    for n in range(1, 2*k + 1):
        somas[n] = sum(xi ** n for xi in x)
    A = []
    B = []
    for i in range(k + 1):
        row = []
        for j in range(k + 1):
            row.append(somas[i + j])
        A.append(row)
        if i == 0:
            B.append(sum(y))
        else:
            B.append(sum(xi ** i * yi for xi, yi in zip(x, y)))
    return np.linalg.solve(A, B)


x =[0.2755, 0.4501, 0.8805, 1.1909, 1.4138, 1.6981, 1.9995, 2.2761, 2.6955, 2.9741, 3.2451, 3.546, 3.8835, 4.2112, 4.6798, 4.7266, 5.077, 5.5175, 5.9286, 6.1925, 6.3867, 6.8411, 7.0397, 7.3697, 7.7885, 7.9212, 8.1662, 8.6627, 8.9418, 9.0774, 9.5547, 9.9998]
y = [5.0725, 5.5868, 6.5783, 7.4578, 8.0227, 8.5329, 9.5126, 10.1104, 11.2552, 12.2102, 12.4703, 13.2624, 14.1151, 14.9174, 16.3787, 16.2438, 17.2823, 18.3979, 19.28, 19.9866, 20.6181, 21.6162, 22.0719, 23.6335, 24.4815, 24.3844, 25.1266, 26.2648, 26.902, 27.3395, 28.8866, 29.2173]
a0, a1 = best_poly(x, y, 1)

print(f'{a0 = } , {a1 = }')


#valores de x
x1= a0 + a1 * 1.5965
x2= a0 + a1 * 1.631
x3= a0 + a1 * 2.4461
x4= a0 + a1 * 3.7443
x5= a0 + a1 * 9.1115

print(x1, x2, x3, x4, x5 )

