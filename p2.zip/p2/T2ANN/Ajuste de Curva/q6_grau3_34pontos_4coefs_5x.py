import numpy as np
# import scipy as sp

def best_poly (x, y, k):
    n = len(x)
    if n <= k:
        raise ValueError('O número de pontos deve ser maior que k (o grau do polinônmio)')

    somas = {}
    somas[0] = n
    for n in range(1, 2*k + 1):
        somas[n] = sum(xi ** n for xi in x)
    A = []
    B = []
    for i in range (k + 1):
        row = []
        for j in range(k + 1):
            row.append(somas[i + j])
        A.append(row)
        if i == 0:
            B.append(sum(y))
        else:
            B.append(sum(xi ** i * yi for xi, yi in zip(x,y)))
    return np.linalg.solve(A, B)

x = [-4.9366, -4.4264, -4.32, -4.0035, -3.6614, -3.4305, -3.1851, -2.7989, -2.6025, -2.2139, -1.8318, -1.7462, -1.2951, -1.0163, -0.7241, -0.5554, -0.2736, 0.1582, 0.5852, 0.6244, 0.9041, 1.3715, 1.5667, 1.8666, 2.2168, 2.4312, 2.6915, 3.1573, 3.384, 3.5314, 3.886, 4.2558, 4.6539, 4.7483]
y =[1.3905, 3.4386, 3.6085, 5.2971, 4.7301, 5.4504, 5.7059, 6.2179, 6.8048, 6.9885, 6.4625, 6.3852, 8.1426, 6.4586, 5.9581, 6.1999, 5.8892, 5.5457, 5.4052, 5.7851, 5.0063, 5.1516, 5.0956, 5.0071, 4.4246, 5.9391, 5.3504, 5.9342, 6.0168, 6.3091, 7.0469, 7.7494, 8.9065, 9.2889]

a0, a1, a2, a3 = best_poly(x, y, 3)

print(f'{a0} , {a1}, {a2}, {a3},') 

values =  [-3.1053, -1.665, -1.6361, -1.1181, 3.4177]

for i in values:
    y = a0 + a1* i + a2* i**2 + a3 * i**3
    print(f"{y}, ")
