import numpy as np
# import scipy as sp

def best_poly (x, y, k):
    n = len(x)
    if n <= k:
        raise ValueError('O número de pontos deve ser maior que k (o grau do polinônmio)')

    somas = {}
    somas[0] = n
    for n in range(1, 2*k + 1):
        somas[n] = sum(xi ** n for xi in x)
    A = []
    B = []
    for i in range (k + 1):
        row = []
        for j in range(k + 1):
            row.append(somas[i + j])
        A.append(row)
        if i == 0:
            B.append(sum(y))
        else:
            B.append(sum(xi ** i * yi for xi, yi in zip(x,y)))
    return np.linalg.solve(A, B)

x = [-4.8516, -4.6615, -4.3262, -3.8516, -3.7682, -3.386, -3.2127, -2.7459, -2.5461, -2.3401, -2.0648, -1.7758, -1.5244, -0.9813, -0.7165, -0.6372, -0.0881, -0.0324, 0.4522, 0.7135, 0.9269, 1.2153, 1.4477, 1.9178, 2.0856, 2.2552, 2.5464, 3.0546, 3.2961, 3.6401, 3.788, 4.0812, 4.5019, 4.6393, 4.8488, 5.2921, 5.474, 5.819]
y =[-7.3535, -5.2611, -2.331, 0.4961, 1.2455, 2.9005, 2.4678, 2.3783, 1.0479, 2.0968, 1.7483, 1.2576, 0.9189, -0.11, -0.1303, -0.232, 0.3048, -1.0062, -0.2149, -1.0714, 0.0274, -0.4151, 0.7694, 2.5623, 2.4581, 2.7208, 3.2788, 5.3965, 4.8157, 5.1468, 4.7854, 4.6213, 3.1658, 2.4348, 1.3595, -3.6463, -5.2924, -10.3932]

a0, a1, a2, a3, a4 = best_poly(x, y, 4)

print(f'{a0} , {a1}, {a2}, {a3}, {a4},') 

values =   [-2.2495, -2.1093, -1.975, -1.5056, 4.2829]
for i in values:
    y = a0 + a1* i + a2* i**2 + a3 * i**3 + a4 * i**4
    print(f"{y}, ")
