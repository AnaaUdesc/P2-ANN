import numpy as np
# import scipy as sp


def best_poly(x, y, k):
    n = len(x)
    if n <= k:
        raise ValueError(
            'O número de pontos deve ser maior que k (o grau do polinônmio)')

    somas = {}
    somas[0] = n
    for n in range(1, 2*k + 1):
        somas[n] = sum(xi ** n for xi in x)
    A = []
    B = []
    for i in range(k + 1):
        row = []
        for j in range(k + 1):
            row.append(somas[i + j])
        A.append(row)
        if i == 0:
            B.append(sum(y))
        else:
            B.append(sum(xi ** i * yi for xi, yi in zip(x, y)))
    return np.linalg.solve(A, B)


x =[0.4581, 0.8933, 1.9865, 2.7547, 3.4661, 4.3365, 5.0679, 6.0358, 7.3838, 7.9138, 9.0812, 9.6868]
y = [4.7314, 5.6417, 9.2014, 10.5912, 12.4864, 14.0015, 16.4911, 18.8498, 22.3939, 23.2436, 26.5734, 28.3404]
a0, a1 = best_poly(x, y, 1)

print(f'{a0 = } , {a1 = }')


#valores de x
x1= a0 + a1 * 0.8453
x2= a0 + a1 * 6.5408
x3= a0 + a1 * 9.1687

print(x1, x2, x3 )

