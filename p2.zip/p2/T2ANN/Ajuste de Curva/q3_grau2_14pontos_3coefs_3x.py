import numpy as np
# import scipy as sp


def best_poly(x, y, k):
    n = len(x)
    if n <= k:
        raise ValueError(
            'O número de pontos deve ser maior que k (o grau do polinônmio)')

    somas = {}
    somas[0] = n
    for n in range(1, 2*k + 1):
        somas[n] = sum(xi ** n for xi in x)
    A = []
    B = []
    for i in range(k + 1):
        row = []
        for j in range(k + 1):
            row.append(somas[i + j])
        A.append(row)
        if i == 0:
            B.append(sum(y))
        else:
            B.append(sum(xi ** i * yi for xi, yi in zip(x, y)))
    return np.linalg.solve(A, B)


x = [0.6417, 0.7836, 1.6149, 2.7509, 3.5061, 3.6218, 4.7216, 5.671, 6.1606, 6.5183, 7.3414, 7.9616, 9.0973, 9.8226]
y = [6.4616, 6.3231, 5.4467, 4.7581, 4.3622, 4.407, 3.8957, 3.7167, 3.6748, 3.8325, 4.0121, 4.2198, 4.819, 5.3221]
a0, a1, a2 = best_poly(x, y, 2)

print(f'{a0 = } , {a1 = }, {a2 = }')

#valores de x
x1= a0 + a1 * 2.014 + a2*(2.014**2)
x2= a0 + a1 * 2.4576 + a2*(2.4576**2)
x3= a0 + a1 * 2.5265 + a2*(2.5265**2)


print(x1, x2, x3, )