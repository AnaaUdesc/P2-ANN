import numpy as np
import math

'''
Encontre os coeficientes a e b da função y=axe^bx que melhor se aproxima da seguinte lista de 12 pontos
(0.8185,2.6099)...
'''
def best_line(x, y, grau=1):
    n = len(x)
    # soma das coordenadas x
    sum_x = sum(x)
    # soma das coordenadas x**2
    sum_x2 = sum(xi ** 2 for xi in x)
    # soma das coordenadas y
    sum_y = sum(y)
    #soma das coordenadas x*y
    sum_xy = sum(xi * yi for xi, yi in zip(x, y))

    # Matriz dos coeficientes
    A = [[n, sum_x], [sum_x, sum_x2]]
    # Matriz dos termos independentes
    B = [sum_y, sum_xy]

    return np.linalg.solve(A, B)

def poly(x, a, b):
    return a*x*np.e**(b*x)
    # return a * (x/(x+b))
    # funcaomath.pow(x,b)

def build_func(a, b):
    def temp(x):
        return poly(x, a, b)
    return temp

if __name__ == '__main__':
    x = [0.2291, 0.4684, 0.7233, 1.0464, 1.2479, 1.3653, 1.6487, 1.8562, 2.1931, 2.2705, 2.497, 2.8214, 3.0231, 3.3907, 3.494, 3.7115, 4.0577, 4.3151, 4.5856, 4.7725, 5.0212, 5.2557, 5.336, 5.6223, 5.9443, 6.0092, 6.3566, 6.5868, 6.8663, 7.1524, 7.2654, 7.6144, 7.7934, 8.0863, 8.3352, 8.5189, 8.6758, 9.0174, 9.1707, 9.4724, 9.56, 9.9421]
    y = [0.78, 1.4685, 2.0797, 2.7972, 3.116, 3.3122, 3.7369, 3.9822, 4.3501, 4.4109, 4.5776, 4.7712, 4.8949, 5.0175, 5.0379, 5.0429, 5.0855, 5.0288, 5.0535, 5.0245, 4.9368, 4.9353, 4.943, 4.7909, 4.6559, 4.6379, 4.5813, 4.3814, 4.3154, 4.1731, 4.1171, 3.9198, 3.9904, 3.7172, 3.6303, 3.5004, 3.4498, 3.3508, 3.2471, 3.114, 3.0673, 2.8843]
    values = [3.5606, 3.7896, 4.8962, 6.8651, 6.9848]
    if min(y) <= 0:
        k1 = abs(min(y)) + 1
    else:
        k1 = 0

    if min(x) <= 0:
        k2 = abs(min(x)) + 1
    else:
        k2 = 0

    yt = [yi + k1 for yi in y]

    y_ = np.log(np.divide(y,x))

    xt = [xi + k2 for xi in x]

    x_ = x
    grau = 1

    a0, a1 = best_line(x_, y_, grau)

    a = np.exp(a0)

    b = a1

    print('Coeficientes da reta')
    print(f'{a0 = } e {a1 = }')

    print('Coeficientes')
    print(f'{a = } e {b = }')

    p = build_func(a, b)

    def q(x):
        return p(x+k2) - k1

    px = [p(vi) for vi in values]
    print(f'{px = }')

    # visualização

""" import matplotlib.pyplot as plt

    plt.scatter(x, y)

    t = np.linspace(min(x), max(x), 200)
    qt = [q(ti) for ti in t]

    plt.plot(t, qt)

    plt.savefig('best_poly_regressao_potencia.png')
    """