import numpy as np
# import scipy as sp

def best_poly (x, y, k):
    n = len(x)
    if n <= k:
        raise ValueError('O número de pontos deve ser maior que k (o grau do polinônmio)')

    somas = {}
    somas[0] = n
    for n in range(1, 2*k + 1):
        somas[n] = sum(xi ** n for xi in x)
    A = []
    B = []
    for i in range (k + 1):
        row = []
        for j in range(k + 1):
            row.append(somas[i + j])
        A.append(row)
        if i == 0:
            B.append(sum(y))
        else:
            B.append(sum(xi ** i * yi for xi, yi in zip(x,y)))
    return np.linalg.solve(A, B)

x =[-4.6332, -3.8555, -2.8827, -2.0953, -0.7131, 0.0811, 0.8807, 1.5839, 2.8595, 3.8799, 4.3684]
y =[5.412, 6.8346, 6.7374, 6.8697, 5.4066, 4.3617, 3.7869, 3.2305, 2.2628, 2.8842, 3.4776]

a0, a1, a2, a3 = best_poly(x, y, 3)

print(f'{a0 = } , {a1 = }, {a2 = }, {a3 = }') 

values = [-1.2316, -0.4611, 2.5288]

for i in values:
    y = a0 + a1* i + a2* i**2 + a3 * i**3
    print(y)
