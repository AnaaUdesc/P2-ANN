import numpy as np
# import scipy as sp


def best_poly(x, y, k):
    n = len(x)
    if n <= k:
        raise ValueError(
            'O número de pontos deve ser maior que k (o grau do polinônmio)')

    somas = {}
    somas[0] = n
    for n in range(1, 2*k + 1):
        somas[n] = sum(xi ** n for xi in x)
    A = []
    B = []
    for i in range(k + 1):
        row = []
        for j in range(k + 1):
            row.append(somas[i + j])
        A.append(row)
        if i == 0:
            B.append(sum(y))
        else:
            B.append(sum(xi ** i * yi for xi, yi in zip(x, y)))
    return np.linalg.solve(A, B)


x = [0.1715, 0.3212, 0.5862, 0.9453, 1.3868, 1.5406, 1.7499, 2.197, 2.4465, 2.7306, 2.9065, 3.2877, 3.3636, 3.8558, 4.0201, 4.1827, 4.4446, 4.885, 5.2349, 5.5267, 5.7736, 5.9741, 6.1202, 6.599, 6.7067, 7.1537, 7.4561, 7.5774, 7.8959, 8.0562, 8.3752, 8.636, 8.9301, 9.2347, 9.6584, 9.9229]
y = [4.4852, 4.5198, 4.1159, 4.0845, 3.8951, 3.8846, 3.8002, 3.6449, 3.5814, 3.4471, 3.5818, 3.386, 3.3683, 3.275, 3.2223, 3.0894, 3.6637, 3.214, 3.7092, 3.4059, 3.3837, 2.9935, 3.4841, 3.6561, 3.9437, 3.454, 3.9181, 4.0246, 4.159, 4.2254, 4.5228, 4.8147, 4.6639, 5.102, 5.1563, 5.6046]
a0, a1, a2 = best_poly(x, y, 2)

print(f'{a0 = } , {a1 = }, {a2 = }')

#valores de x
x1= a0 + a1 * 3.4784 + a2*(3.4784**2)
x2= a0 + a1 * 3.9932 + a2*(3.9932**2)
x3= a0 + a1 * 4.9108 + a2*(4.9108**2)
x4= a0 + a1 * 4.9394 + a2*(4.9394**2)
x5= a0 + a1 * 9.1946 + a2*(9.1946**2)


print(x1, x2, x3, x4, x5 )