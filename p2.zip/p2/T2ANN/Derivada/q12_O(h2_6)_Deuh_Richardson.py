'''
Considere a função 𝑓(𝑥)=𝑥^2* tan(sin(𝑥/𝜋)). A fórmula

        𝐹1(ℎ) = 𝑓(𝑥0+ℎ)−𝑓(𝑥0)/ℎ

é usada para aproximar 𝑓′(𝑥0) com erro 𝑂(ℎ1). Use o método de extrapolação de 
Richardson sobre a fórmula 𝐹1 para obter aproximações para 𝑓′(1.16804) com erros 𝑂(ℎ2), 
𝑂(ℎ3), 𝑂(ℎ4), 𝑂(ℎ5) e 𝑂(ℎ6). Use ℎ=0.41563.


'''





import random
import numpy as np
import math

def richardson(x,b=1):
    n = len(x)
    for k in range(1, n):
        for i in range(n - k):
            numer = 2 ** (b*k) * x[i+1] - x[i]
            denom = 2 ** (b*k) -1
            aprox = numer/ denom 
            x[i]= aprox  
    return x[0]

if __name__ == '__main__':
    
    def f(x):
        return ((x**2) * math.tan(math.sin(x/math.pi)))

    x0 = 1.16804
    h = 0.41563

    def F1(h):
        return (f(x0+h)- f(x0))/h

    #col_F1 = [F1(h)]
    #col_F1 = [F1(h),F1(h/2)]
    #col_F1 = [F1(h),F1(h/2),F1(h/4)]
    #col_F1 = [F1(h),F1(h/2),F1(h/4),F1(h/8),]
    #col_F1 = [F1(h),F1(h/2),F1(h/4),F1(h/8),F1(h/16)]
    col_F1 = [F1(h),F1(h/2),F1(h/4),F1(h/8),F1(h/16),F1(h/32)]
    



    print(f'{col_F1 = }')
    aprox = richardson(col_F1)
    print(f'Aprox para f\'({x0})~{aprox} com erro O(h^{len(col_F1)})')
    
