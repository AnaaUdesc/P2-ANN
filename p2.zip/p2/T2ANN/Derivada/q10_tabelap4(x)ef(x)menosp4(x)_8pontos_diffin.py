'''
De acordo com o teorema de Taylor, toda função 𝑛+1 vezes derivável pode ser aproximada
por um polinômio de grau 𝑛, mais precisamente, se 𝑓 é 𝑛+1 vezes derivável num ponto 𝑥0,
 então para todo 𝑥 suficientemente próximo de 𝑥0, existe um 𝑐, entre 𝑥 e 𝑥0, tal que

                𝑓(𝑥)=𝑝𝑛(𝑥)+𝑟𝑛(𝑥),

onde

    𝑝𝑛(𝑥)=𝑓(𝑥0)+𝑓′(𝑥0)(𝑥−𝑥0)+𝑓″(𝑥0)2!(𝑥−𝑥0)2+⋯+𝑓(𝑛)(𝑥0)𝑛!(𝑥−𝑥0)𝑛

e

                𝑟𝑛(𝑥)=𝑓(𝑛+1)(𝑐)(𝑛+1)!(𝑥−𝑥0)(𝑛+1)

O polinômio 𝑝𝑛(𝑥) é chamado o polinômio de Taylor de grau 𝑛 da função 𝑓 em torno do 
ponto 𝑥0. Esse polinômio pode ser usado para estimar os valores de 𝑓(𝑥) para 𝑥 próximo de 
𝑥0 e o erro cometido nessas aproximações é medido pela função 𝑟𝑛(𝑥).
Sabendo disso, encontre o polinômio de Taylor de grau 4 da função

                    𝑓(𝑥)=ln(2+cos(𝑒^(−𝑥)))

em torno do ponto 𝑥0=0.4291, ou seja, encontre as derivadas de 𝑓 no ponto 𝑥0=0.4291 
até a ordem 4 para construir o seguinte polinômio de Taylor

    𝑝5(𝑥)=𝑓(𝑥0)+𝑓′(𝑥0)(𝑥−𝑥0)+𝑓″(𝑥0)2!(𝑥−𝑥0)2+𝑓‴(𝑥0)3!(𝑥−𝑥0)3+𝑓(4)(𝑥0)4!(𝑥−𝑥0)4+𝑓(5)(𝑥0)5!(𝑥−𝑥0)5

Em seguida, use esse polinômio para estimar o valor de 𝑓(𝑥) nos seguintes valores de 𝑥


   𝑥=0.2049, 𝑥=0.2348, 𝑥=0.278  e  𝑥=0.3258

e compare os resultados com os valores exatos de 𝑓 nesses pontos, ou seja, para cada valor 
de 𝑥 dado acima calcule o erro |𝑓(𝑥)−𝑝4(𝑥)|. Para o cálculo das derivadas acima, use o 
método das diferenças finitas com os seguintes pontos

   𝑥1=0.1945 , 𝑥2=0.2549, 𝑥3=0.3294, 𝑥4=0.3747, 𝑥5=0.4763, 𝑥6=0.5537, 
                            𝑥7=0.5752  e  𝑥8=0.6684

'''


import random
import numpy as np
import math


def prod(lst):
    p = 1
    for i in lst:
        p *= i
    return p


def finite_diffs(xs, ordem, x0, f):
    A = []
    B = []
    n = len(xs)
    for i in range(n):
        A.append([0]*n)
        for j in range(n):
            A[i][j] = xs[j] ** i
        potencias = [k + 1 for k in range(i - ordem, i)]
        fatorial = 0 if i < ordem else prod(potencias)
        termo = fatorial * x0 ** (i - ordem)
        B.append(termo)
    A = np.array(A, dtype='float')
    B = np.array(B, dtype='float')
    cs = np.linalg.solve(A, B)
    soma = 0
    for ck, xk in zip(cs, xs):
        soma += ck * f(xk)
    return soma


def f(x):
    return  math.log(2 + math.cos(math.exp(-x)))


x0 = 0.4291
ordem = 4
xs =[0.1945, 0.2549, 0.3294, 0.3747, 0.4763, 0.5537, 0.5752, 0.6684]
values = [0.2049, 0.2348, 0.278, 0.3258]

# x0 = -1.911
# ordem = 4
# xs = [-2.128, -2.0467, -2.0268, -1.9416, -1.8746, -1.8358, -1.7743, -1.6719]
# values = [-1.9949, -1.9367, -1.8527, -1.7989]

ordem1 = 1
ordem2 = 2
ordem3 = 3
ordem4 = 4

p = 0
n = len(values)
for i in range(n):
    p = f(x0) + finite_diffs(xs, ordem1, x0, f)*(values[i] - x0) + ((finite_diffs(xs, ordem2, x0, f)/2) * ((values[i]-x0)**2)) + (
        (finite_diffs(xs, ordem3, x0, f)/6) * ((values[i]-x0)**3)) + ((finite_diffs(xs, ordem4, x0, f)/24) * ((values[i]-x0)**4))
    erroN = math.sqrt(((f(values[i]) - p)**2))
    print(f'{values[i]} = {p} e |f(x) - p3(x)| = {erroN}')

num_pontos = 0
a = x0 - 0.25
b = x0 + 0.25
#xs = [a + (b - a) * random.random() for _ in range(num_pontos)]
# xs.sort()

#r = finite_diffs(xs, ordem, x0, f)
# print(xs)
#print(f'aprox para derivada de ordem {ordem} de f no ponto {x0} {r}')
