
'''
Use o método das diferenças finitas e a seguinte lista de 7 pontos


𝑥1=−4.6385, 𝑥2=−4.5771, 𝑥3=−4.501, 𝑥4=−4.4838, 𝑥5=−4.3811,
                     𝑥6=−4.3366  e  𝑥7=−4.2589

para encontrar uma aproximação para 𝑓‴(𝑥0), onde 
𝑓(𝑥)=sin^4(𝑥)−4*sin^2(𝑥)+cos(𝑥^2)+𝑒^(−𝑥^2)+5 e  𝑥0=−4.4488


'''

import numpy as np
import math

# x0 = ponto onde a função será derivada
# x = lista de coordenadas na proximidade de x0
# y = cálculo da função em todos os pontos x
# k = ordem da derivada


def coeffs_dif_fin(x0, x, k):
    n = len(x)
    A, B = [[1] * n], [0]
    for i in range(1, n):
        # construção da matriz A
        row_i = [xi ** i for xi in x]
        A.append(row_i)
        # construção da matriz B
        if i < k:
            B.append(0)
        elif i == k:
            B.append(math.factorial(k))
        else:
            numer = math.factorial(i)
            denom = math.factorial(i - k)
            el = (numer / denom) * x0 ** (i - k)
            B.append(el)
    return np.linalg.solve(A, B)


def dif_fin(coeffs, y):
    return sum(ci * yi for ci, yi in zip(coeffs, y))


if __name__ == '__main__':
    # exemplo 1:
    def f(x):
        return  math.sin(x)**4 - 4*math.sin(x)**2 + math.cos(x**2) + math.exp(-x**2) + 5

    x0 = -4.4488
    x = [-4.6385, -4.5771, -4.501, -4.4838, -4.3811, -4.3366, -4.2589]

    # x0 = 2
    k = 3
    n = 10  # numero de pontos igualmente espaçados
    # queremos pontos no intervalo [x0-e, x0+e]
    # ao diminuir o epsilon (e) os pontos são cada vez mais próximos
    e = 0.1
    # x = np.linspace(x0 - e, x0 + e, n)
    y = [f(xi) for xi in x]

    coeffs = coeffs_dif_fin(x0, x, k)
    aprox = dif_fin(coeffs, y)
    print(f'{coeffs = }')
    print(f'{aprox = }')
