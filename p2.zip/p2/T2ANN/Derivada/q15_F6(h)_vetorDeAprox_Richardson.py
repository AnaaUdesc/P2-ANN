
'''
Considere a função 𝑓(𝑥)=𝑥^2* 𝑒^(−𝑥)cos(𝑥)+1. Os valores

    𝐹1(ℎ)=−0.3817489730080119, 𝐹1(ℎ/2)=−0.3576941235873665, 
    𝐹1(ℎ/4)=−0.3450779836713167,𝐹1(ℎ/8)=−0.33864129924688413, 
    𝐹1(ℎ/16)=−0.3353931055692172  e  𝐹1(ℎ/32)=−0.3337618320849458

são aproximações para 𝑓′(2.32922) com erro 𝑂(ℎ1). Use o método de extrapolação de
 Richardson para encontrar uma aproximação com erro 𝑂(ℎ6) para 𝑓′(2.32922).


'''
from cmath import cos, e
import math


def richardson(col1):
    col1 = [item for item in col1]
    n = len(col1)
    for j in range(n - 1):
        temp_col = [0] * (n-1-j)
        for i in range(n - 1 - j):
            power = j + 1
            temp_col[i] = (2 ** power * col1[i+1] - col1[i]) / (2 ** power - 1)
        col1[:n - 1 - j] = temp_col
        print(temp_col)
    return col1[0]


def func(x):
    return x**2 * math.exp(-x)*math.cos(x)+1


if __name__ == '__main__':

    x0 = 2.32922
    approximations = [-0.3817489730080119, -0.3576941235873665, -0.3450779836713167, -0.33864129924688413, -0.3353931055692172, -0.3337618320849458]
    aprox = richardson(approximations)

    print(f'{aprox = }')
