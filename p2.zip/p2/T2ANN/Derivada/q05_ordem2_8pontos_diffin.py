'''Use o método das diferenças finitas e a seguinte lista de 8 pontos

    x𝑥1=3.7692, 𝑥2=3.8053, 𝑥3=3.868, 𝑥4=3.9476, 𝑥5=3.9849, 𝑥6=4.0497,
                         𝑥7=4.1241  e  𝑥8=4.202

para encontrar uma aproximação para f′′′(x0), onde 
    𝑓(𝑥)=√cos(𝑥^2)+𝑥  e 𝑥0=3.9805.'''

from cmath import exp
import numpy as np
import math

def coeffs_dif_fin(x0, x, k):
    n = len(x)
    A, B = [[1] * n], [0]
    for i in range(1, n):
        # construção da matriz A
        row_i = [xi ** i for xi in x]
        A.append(row_i)
        # construção da matrz B
        if i < k:
            B.append(0)
        elif i == k:
            B.append(math.factorial(k))
        else:
            numer = math.factorial(i)
            denom = math.factorial(i - k)
            el = (numer / denom) * x0 ** (i - k)
            B.append(el)
    A = np.array(A, dtype=float)
    B = np.array(B, dtype=float)
    return np.linalg.solve(A, B)

def dif_fin(coeffs, y):
    return sum(ci * yi for ci, yi in zip(coeffs, y))


if __name__ == '__main__':
    
    def f(x):
        return math.sqrt(math.cos(x**2) + x)

    k = 2 # ordem
    n = 8 # número de pontos
    x0 = 3.9805
    x = [3.7692, 3.8053, 3.868, 3.9476, 3.9849, 4.0497, 4.1241, 4.202]



    # queremos pontos no intervalo [x0-e, x0+e]
    e = 0.1 # tolerancias
    # x = np.linspace(x0 - e, x0 + e, n)
    
    y = [f(xi) for xi in x]

    coeffs = coeffs_dif_fin(x0, x, k)
    aprox = dif_fin(coeffs, y)

   # print(f'{coeffs}')
    print(f'{aprox}')