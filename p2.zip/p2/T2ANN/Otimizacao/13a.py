'''
Suponha que a força de resistência do ar sobre um objeto em queda livre é proporcional ao quadrado da velocidade. Neste caso, a velocidade pode ser calculada usando-se
𝑣(𝑡)=√𝑔𝑚/𝑐𝑑* tanh(√𝑔𝑐𝑑/𝑚 *𝑡),
onde 𝑐𝑑 é um coeficiente de arrasto de segunda ordem. Sabendo que 𝑔=9.81𝑚/𝑠2, 𝑚=71.65𝑘𝑔 e 𝑐𝑑=0.2𝑘𝑔/𝑚. Use
𝑎) a regra dos trapézios com 32 subintervalos
𝑏) a regra de Simpson com 16 subintervalos
𝑐) o método de Romberg com ℎ=7.5/10 para obter uma aproximação com erro 𝑂(ℎ8)
𝑑) o método da Quadratura Gaussiana que seja exato em polinômios de grau menor que 10
para determinar a distância percorrida pelo objeto após 7.5𝑠.
'''
import numpy as np
import math

def trapezio(f, a, b, n):
    h = (b - a) / n
    soma = 0
    for k in range(1, n):  # comecar em 1 evitando que o primeiro ponto seja calculado 2 vezes
        soma += f(a + k * h)
    soma *= 2
    soma += (f(a) + f(b))
    soma *= (h / 2)
    return soma

if __name__ == '__main__':

    def f(x):
        return math.sqrt((9.81*71.65)/(0.2))*math.tanh(math.sqrt((9.81*(0.2))/71.65)*x)

a_t = 0
b_t = 7.5

subintervalos_t = [32]

n_t = len(subintervalos_t)
for i in range(n_t):
    result_t = trapezio(f,a_t, b_t, subintervalos_t[i])
    print(f'{result_t}')