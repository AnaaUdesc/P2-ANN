


def trapz(f, a, b, n):
    soma = f(a) + f(b)
    h= (b-a)/n
    for k in range(1,n):
        xk = a + k*h
        soma += 2 * f(xk)
    return (h/2) * soma

def gschimit(funcs):

# a_ki = <fk,gi>/<gi,gi>
# i= 1,2,3,4..., k-1

    a=-1
    b=-1
    num_intervalos=256

    ortogonais =[funcs[0]]
    for k, fk in enumerate(funcs[1:],1):
        coefs_gk= []
        for i, gk in enumerate(ortogonais,1):
        
            numer = trapz(lambda x: fk(x)*gi(x),a,b,num_intervalos)
            
            denom = trapz(lambda x:gi(x)**2,a,b,num_intervalos)
            a_ki = numer /denom
            coefs_gk.append(a_ki)
            print(f'a{k}{i} = {a_ki}\t', end= "")
        def gk(x):
            return fk(x) -sum(a*g(x) for a, g in zip(coefs_gk,ortogonais))
        ortogonais.append(gk)
        print()









if __name__ == '__main__':

    def f1(x):return 1
    def f2(x):return 1
    def f3(x):return x**2
    def f4(x):return x**3


    funcs=[f1, f2, f3, f4]

    gschimit(funcs)