import numpy as np
import math

def trapz(f, a, b, n):
    soma = f(a) + f(b)
    h= (b-a)/n
    for k in range(1,n):
        xk = a + k*h
        soma += 2 * f(xk)
    return (h/2) * soma

def aprox(f, f_list):
    n = len(f_list)
    A = [[0 for _ in range(n)] for _ in range(n)]  #A é simetrica
    B = []
    for i in range(n):
        for j in range(i, n): #elementos na diagonal da matriz 
             def f_ji(x):
                return f_list[j](x) * f_list[i](x)
             #altere depedndeno do metdodo de integraçao
             a, b = -math.pi, math.pi
             num_intervals = 256 #numero de subintervalos para integrar no metodo do trapz
             a_ij = trapz (f_ji,a,b,num_intervals) #inetgral de f_j *f_i
             #nao altere mais
             A[i][j] = a_ij
             A[j][i] = a_ij
        def ff_i(x):
            return f(x) * f_list[i](x)
        #altere depedndeno do metdodo de integraçao
        a, b = -math.pi, math.pi
        num_intervals = 256 #numero de subintervalos para integrar no metodo do trapz
        b_i = trapz (ff_i,a,b,num_intervals) #inetgral de f *ff_i
        #nao altere mais
        B.append(b_i)
    return np.linalg.solve(A,B)


def build_g(coefs, f_list):
    def func_g(x):
        return sum (ci* fi(x) for ci, fi in zip (coefs, f_list))
    return func_g

if __name__ == '__main__':

    def f(x):
        if x < 0 :
            return 1
        return 2


    a, b = -math.pi, math.pi


    def f1(x) : return 1
    def f2(x) : return np.cos(x)
    def f3(x) : return np.sin(x)
    def f4(x) : return np.cos(3*x)
    def f5(x) : return np.sin(3*x)
    def f6(x) : return np.cos(5*x)
    def f7(x) : return np.sin(5*x)
    def f8(x) : return np.cos(7*x)
    def f9(x) : return np.sin(7*x)


    f_list =[f1,f2,f3,f4,f5,f6,f7,f8,f9]

    coefs = aprox(f, f_list)
    #essa é a funçao g que melhor se aproxima f(x)
    g = build_g(coefs, f_list)

    print(coefs)

    result = g(2)

    print(result)
    






            

 