'''
A seguinte lista de 7 pontos
(0.152,1.73), (1.548,2.203), (1.986,2.0), (2.138,2.019), (2.354,2.125), (2.431,2.185) e
                     (4.043,1.142)
vive no gráfico de uma função 𝑓. Use a regra dos trapézios para aproximar a área embaixo 
do gráfico de 𝑓 no intervalo [0.152,4.043].

'''


x = [0.152, 1.548, 1.986, 2.138, 2.354, 2.431, 4.043]

y = [1.73, 2.203, 2.0, 2.019, 2.125, 2.185, 1.142]
soma = 0
xy = zip(x, y)

for a2, b2 in zip(x[1:], y[1:]):  # lista de x e y removidos os primeiros elementos
    for a1, b1 in zip(x, y):
        soma += ((a2-a1) * (b2 + b1))/2.0
        x.pop(0)  # removendo os primeiros elementos das listas de x e y
        y.pop(0)
        break

print('soma de verdade?', soma)
