'''A seguinte lista de 21 pontos
(0.307,2.272), (0.5275,2.827), (0.748,3.0), (0.8765,2.953), (1.005,2.836), 
(1.0865,2.741), (1.168,2.638), (1.525,2.224), (1.882,2.014), (1.9035,2.009), 
(1.925,2.006), (2.218,2.048), (2.511,2.258), (2.856,2.669), (3.201,2.992),
 (3.29,2.996), (3.379,2.946), (3.411,2.913), (3.443,2.872), (3.47,2.831) e 
                        (3.497,2.784)
vive no gráfico de uma função f. Use a regra de Simpson para aproximar a 
área embaixo do gráfico de f no intervalo [0.307,3.497]..'''

def simps(f, a, b, n):
    if n % 2 != 0 or n < 1:
        raise ValueError("n deve ser par e maior q 1")
    h = (b - a) / n
    soma_odd, soma_even = 0, 0
    for k in range(1,n,2):
        soma_odd += f(a+k*h)
    for k in range(2,n,2):
        soma_even += f(a + k * h)
    return (h/3) * (f(a) + 4 * soma_odd + 2 * soma_even + f(b))

def simp(x0,x1,x3,y0,y1,y2):
    return ((x1-x0)/3)*(y0+4*y1+y2)

def simpsPonto(x, y):
    tam = (len(x) - 1) // 2
    somas = 0
    k = 0
    for i in range(tam):
        somas += simp(x[k],x[k+1],x[k+2],y[k],y[k+1],y[k+2])
        k += 2
    print(f'{somas}')


x = [0.307, 0.5275, 0.748, 0.8765, 1.005, 1.0865, 1.168, 1.525, 1.882, 1.9035, 1.925, 2.218, 2.511, 2.856, 3.201, 3.29, 3.379, 3.411, 3.443, 3.47, 3.497]
y = [2.272, 2.827, 3.0, 2.953, 2.836, 2.741, 2.638, 2.224, 2.014, 2.009, 2.006, 2.048, 2.258, 2.669, 2.992, 2.996, 2.946, 2.913, 2.872, 2.831, 2.784]

simpsPonto(x, y)