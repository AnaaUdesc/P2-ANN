'''

Use a regra dos Trapézios para aproximar o valor da integral

  1.264
∫         (sin(𝑥/(√𝑥^2+1)+1)𝑑𝑥.
  −1.684
Use os números de subintervalos a seguir:
    𝑛=1,15,46,58,89,101,193,336,638,958,1411,8051


'''


import numpy as np
import math

def trapezio(f, a, b, n):
    h = (b - a) / n
    soma = 0
    for k in range(1, n):  # comecar em 1 evitando que o primeiro ponto seja calculado 2 vezes
        soma += f(a + k * h)
    soma *= 2
    soma += (f(a) + f(b))
    soma *= (h / 2)
    return soma

if __name__ == '__main__':

    def f(x):
        return math.sin (x/math.sqrt(x**2+1))+1

a = -1.684
b =  1.264

subintervalos = [1, 15, 46, 58, 89, 101, 193, 336, 638, 958, 1411, 8051]

n = len(subintervalos)
for i in range(n):
    result = trapezio(f,a, b, subintervalos[i])
    print(f'{result},')


