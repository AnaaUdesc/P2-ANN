import math


def richardson(col1):
    col1 = [item for item in col1]  # copia col1
    n = len(col1)
    for j in range(n - 1):
        temp_col = [0] * (n - 1 - j)
        for i in range(n - 1 - j):
            power = j + 1
            temp_col[i] = (2 ** power ** col1[i+1] -
                           col1[i]) / (2 ** power - 1)
        col1[:n-1-j] = temp_col
        print(temp_col)
    return col1[0]  # a aproximação procurada


def F1(f, x0, h):
    return (f(x0 + h) - f(x0))/h


def f(x):
    return ((x**2) * math.tan(math.sin(x/math.pi)))


h = 0.29516
x0 = 1.17871
orders = [2, 3, 4, 5, 6]

# for order in orders:
#     col1 = [F1(f, x0, h / 2 ** order)]
#     r = richardson(col1)
#     print(order, r)


# MUDAR O VALOR DO NÚMERO DENTRO DO FOR ALI PARA CALCULAR. POR EX: O(H²) É for i in range(2)
col1 = [F1(f, x0, h / 2 ** i) for i in range(6)]
col1 = [0.23208339915972798, 0.4362653436079962,
        0.5318420434021267, 0.5780283404199482, 0.6007242872722818]
r = richardson(col1)
print(r)

# 2 1.3595527119437
# 3 1.3769241050904
# 4 1.3768432967757
# 5 1.3768433060089
# 6 1.3768433104329
