#include <stdio.h>
#include <math.h>

#define ROWS 3
#define COLS 4

double e = 2.718281828459045235360287;
double pi = 3.14159265359;

void print_matrix(double array[ROWS][COLS]);
void gauss(double E[ROWS][COLS]);
void reverse_substitution(double E[ROWS][COLS]);

int main(void){
    // F1, F2, F3, H2, V2, V3,
    double E[ROWS][COLS] = {{ 1, 1, -1, 0},
    {-21, 10, 0, 77},
    { 0, -10, -12, 65},
    {-21, 0, -12, 142}

    };

    print_matrix(E);

    gauss(E);

    reverse_substitution(E);

}

void print_matrix(double array[ROWS][COLS]){
    for(int i = 0; i < ROWS; i++){
        for(int j = 0; j< COLS; j++){
            printf("%.8f\t",array[i][j]);
        }
        printf("\n");
    }
}

void gauss(double E[ROWS][COLS]){
    int i,j,k,m,n;
    double temp, a;

    for( j = 0; j for( i = j; i if(E[i][j] != 0){
         != j){
        // trocar linhas
        for(k=0;k temp = E[i][k];
            E[i][k] = E[j][k];
            E[j][k] = temp;
        }
    }
    // O pivot (Elemento E[i][j] seja nao nulo)
    for(m = j+1; m a = -E[m][j] / E[j][j];
    for(n=j; n E[m][n] += a *E[j][n];
    }
    }
    print_matrix(E);printf("\n");
    break;
    }
    else{
    if( i == ROWS -1){
    printf("Sistema sem solucao\n");
    }
    }
    }
    }
}

void reverse_substitution(double E[ROWS][COLS]){
    double answer[ROWS];

    for(int i=0; i int d = ROWS - 1 - i;
    double b = E[d][COLS -1];
    for(int j = d+1; j b -= E[d][j] * answer[j];

    }
    double xd = b/E[d][d];
    answer[d] = xd;
    printf("X_%d = %.16f\n",d,xd);
    }
}