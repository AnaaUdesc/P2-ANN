import numpy as np

g = 9.81
m1 = 4.68
m2 = 2.07
m3 = 5.62
k1 = 91.0
k2 = 60.56
k3 = 95.53

# m_1 = (k1+k2)*x1 - k2*x2 = m1*g

# m_2 = k2*x1 - (k2+k3)*x2 + k3*x3 = -m2*g

# m_3 = k3(x3 - x2) - k3*x3 = m3*g
# m_3 = k3*x3 - k3*x2 - k3*x3 = m3*g

# m_3 = - k1*x1 - k3*x3 + k2*x2 + k3*x2 + m3*g = 0
# m_3 = k1*x1 -(k2+k3)*x2 + k3*x3 = m3*g

# print()
# print(f'{k1+k2}*x1 {-k2}*x2 + 0*x3 = {m1*g}')
# print(f'{k2}*x1 {-(k2+k3)}*x2 + {k3}*x3 = {-m2*g}')
# print(f'{k3}*x1 {-k2}*x2 + {k3}*x3 = {m3*g}')
# print()

# new try: (worked!!!!!)
# m_1 = (k1+k2)*x1 - k2*x2 = m1*g

# m_2 = -k2*(x2-x1) + k3*(x3-x2) = -m2*g
# m_2 = -k2*x2 + k2*x1 + k3*x3 -k3*x2 = -m2*g
# m_2 = -(k2+k3)*x2 + k2*x1 + k3*x3 = -m2g
# m_2 =  k2*x1 -(k2+k3)*x2 + k3*x3 = -m2g
# m_2 =  - k2*x1 + (k2+k3)*x2 - k3*x3 = m2g

# m_3 = -k3*(x3-x2) + m3*g = 0
# m_3 = -k3*(x3-x2) = - m3*g
# m_3 = -k3*x3 + k3*x2 = - m3*g
# m_3 = k3*x2 - k3*x3 = - m3*g
# m_3 = - k3*x2 + k3*x3 = m3*g

K = [
    [k1+k2,     -k2,        0],
    [-k2,        (k2+k3),   -k3],
    [0,        -k3,   k3]
]
X = []
W = [m1*g, m2*g, m3*g]

MATRIZ_K = np.array(K)
MATRIZ_W = np.array(W)
MATRIZ_K_INVERSA = np.linalg.inv(MATRIZ_K)

print('K =\n', MATRIZ_K)
print('\nK^-1 * W =', np.dot(MATRIZ_K_INVERSA, MATRIZ_W), '\n')


# resposta esperada =
x1 = 1.4656990801577
x2 = 2.4761600917488
x3 = 2.7846506577866
MATRIZ_X = np.array([x1, x2, x3])

print('\nTESTE:')
print('K * X =', np.dot(MATRIZ_K, MATRIZ_X))
print('W =', MATRIZ_W)
print()
