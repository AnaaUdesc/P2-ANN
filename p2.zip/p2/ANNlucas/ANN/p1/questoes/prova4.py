import numpy as np


def f(x):
    return np.cos(np.exp(-x**2)) + np.sin((x**2/2))
    # return np.exp(np.cos(x)**2)+np.exp(-x**2)+np.log(x)


# def f(x):
    # return 1/(1 + 25*(x**2))


def poly(x, y):
    n = len(x) - 1
    A = []
    for xi in x:
        row = [1]
        for j in range(1, n + 1):
            row.append(xi**j)
        A.append(row)
    return np.linalg.solve(A, y)


def p(x, coefs):
    first = coefs[0]
    return first + sum([ai*x**j for j, ai in enumerate(coefs[1:], 1)])


if __name__ == '__main__':
    x = [0.801, 2.162, 3.033]
    y = []

    for i in x:
        y.append(f(i))

    np.set_printoptions(suppress=True)
    coefs = poly(x, y)
    print(coefs)
    print(abs(f(1.676) - p(1.676, coefs)))
    print(abs(f(3.299) - p(3.299, coefs)))
    print(abs(f(5.809) - p(5.809, coefs)))  # pontos
