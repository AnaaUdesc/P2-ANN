
def seide(matrix_a, matrix_b, chute, n):
    for k in range(n):
        for i in range(len(matrix_a)):
            bi = matrix_b[i]
            for j in range(len(matrix_a)):
                if(j != i):
                    bi -= matrix_a[i][j] * chute[j]
            bi /= matrix_a[i][i]
            print('x_%d^(%d) = %.16f\t' % (i+1, k+1, bi))
            chute[i] = bi


def main():
    matrix_a = [
        [7.31, -3.25, 2.35],
        [-4.49, 7.41, -1.21],
        [-3.96, -4.55, 10.23],
    ]
    matrix_b = [-1.58, 0.45, -2.27]
    chute = [-4.74, -2.39, -0.43]
    n = 18

    seide(matrix_a, matrix_b, chute, n)


main()
