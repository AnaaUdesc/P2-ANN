import matplotlib.pyplot as plt
import numpy as np


def lagrangee(x, y):
    num = len(x)
    coeffs = []
    for i in range(num):
        prod = 1
        for j in range(num):
            if i != j:
                prod *= (x[i] - x[j])
        ci = y[i] / prod
        coeffs.append(ci)
    return coeffs


def pl(t, x, coeffs):
    soma = 0
    num = len(coeffs)
    for i in range(num):
        prod = 1
        for j in range(num):
            if i != j:
                prod *= (t - x[j])
        prod *= coeffs[i]
        soma += prod
    return soma


def poly(x, coeffs):
    def f(t):
        return pl(t, x, coeffs)
    return f


def main():
    # x = [1, 1.5, 2, 3, 4]
    # y = [0, -1, -3, 0, -1]
    x = [1.852, 2.976, 3.627, 4.127, 5.018]
    y = [1.234, 4.049, 5.008, 2.46, 3.188]

    coeffs = lagrangee(x, y)
    lagr = poly(x, coeffs)
    print(lagr(3.212), lagr(4.261), lagr(4.486))

    plt.scatter(x, y)

    t = np.linspace(min(x), max(x), 100)
    lt = [lagr(ti) for ti in t]

    plt.plot(t, lt)

    plt.show()


main()
