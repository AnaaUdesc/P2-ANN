import math


def f(x):
    return ((12*x*x) - (113.32*x) + 181.2432)


def secante(x0, x1, n):
    fx0 = f(x0)
    fx1 = f(x1)
    if(fx0 == fx1):
        print('Escolha outra estimativa inicial')
    else:
        for i in range(n):
            x2 = (x0 * fx1 - x1 * fx0) / (fx1 - fx0)
            fx0 = fx1
            fx1 = f(x2)

            if(fx0 == fx1):
                print("x_%d = %.16f (precisei parar)" % (i+2, x2))
                return
            else:
                print("x_%d = %.16f" % (i+2, x2))
                x0 = x1
                x1 = x2


def main():
    x0 = 0.88
    x1 = 3.9
    n = 5

    secante(x0, x1, n)


main()
