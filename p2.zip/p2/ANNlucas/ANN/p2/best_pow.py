import matplotlib.pyplot as plt
import numpy as np


def bestpoly(x, y, grau):
    k = grau + 1
    A = np.zeros((k, k))
    # A = [[0 for _ in range(k)] for _ in range(k)]
    B = [sum(y)]

    n = len(x)
    cache = {}
    for i in range(k):
        for j in range(k):
            p = i + j
            if p == 0:
                A[0][0] = n
                continue
            if p not in cache:
                cache[p] = sum([xi ** p for xi in x])
            A[i][j] = cache[p]
        if(i > 0):
            B.append(sum([yi * xi ** i for xi, yi in zip(x, y)]))

    return np.linalg.solve(A, B)


def poly(x, a, b):
    return a * x ** b


def build_func(a, b):
    def temp(x):
        return poly(x, a, b)
    return temp


def modelo(x):
    a, b = -1, 5
    erro = a + (b-a) * np.random.random()
    return 1.36 * x ** 3.89 + erro


def main():

    x = np.linspace(1, 3, 20)
    print(f'{x = }')
    y = [modelo(xi) for xi in x]
    print(f'{y = }')

    # transladar os pontos para cima
    k = abs(min(y)) + 1
    yt = [yi + k for yi in y]
    print(f'{y = }')

    x_ = np.log(x)
    y_ = np.log(y)

    grau = 1

    a0, a1 = bestpoly(x_, y_, grau)

    a = np.exp(a0)
    b = a1

    print(f'{a0 = } e {a1 = }')

    p = build_func(a, b)

    def q(x):
        return p(x) - k

    plt.scatter(x, y)
    t = np.linspace(min(x), max(x), 200)
    pt = [p(ti) for ti in t]
    plt.plot(t, pt)
    plt.show()


main()
