import matplotlib.pyplot as plt
import numpy as np


def bestpoly(x, y, grau):
    k = grau + 1
    A = np.zeros((k, k))
    # A = [[0 for _ in range(k)] for _ in range(k)]
    B = [sum(y)]

    n = len(x)
    cache = {}
    for i in range(k):
        for j in range(k):
            p = i + j
            if p == 0:
                A[0][0] = n
                continue
            if p not in cache:
                cache[p] = sum([xi ** p for xi in x])
            A[i][j] = cache[p]
        if(i > 0):
            B.append(sum([yi * xi ** i for xi, yi in zip(x, y)]))

    return np.linalg.solve(A, B)


def poly(x, a, b):
    return a * np.exp(b * x)


def build_func(a, b):
    def temp(x):
        return poly(x, a, b)
    return temp


def modelo(x):
    a, b = -40, -30
    erro = a + (b-a) * np.random.random()
    return 2.5 * np.e ** (1.47 * x) + erro


def main():
    # x = [-2, -1, 0, 1, 3]
    # y = [2, 0, 1, 2, 1.5]
    # grau = 2

    x = np.linspace(-2, 2, 50)
    # print(f'{x = }')
    y = [modelo(xi) for xi in x]
    # print(f'{y = }')

    # transladar os pontos para cima
    k = abs(min(y)) + 1
    yt = [yi + k for yi in y]
    print(f'{y = }')

    y_ = np.log(yt)

    grau = 1

    a0, a1 = bestpoly(x, y_, grau)

    a = np.exp(a0)
    b = a1

    print(f'{a0 = } e {a1 = }')

    p = build_func(a, b)

    def q(x):
        return p(x) - k

    plt.scatter(x, y)
    t = np.linspace(min(x), max(x), 200)
    qt = [q(ti) for ti in t]
    plt.plot(t, qt)
    plt.show()


main()
