# requer número impar de pontos
import math


def simps(f, a, b, n):
    h = (b - a) / n
    soma_impar = sum([f(a + k * h) for k in range(1, n, 2)])
    soma_par = sum([f(a + k * h) for k in range(2, n, 2)])
    return (h/3) * (f(a) + 4 * soma_impar + 2 * soma_par + f(b))


def f(x):
    return math.sqrt(1 + (math.cos(x)**2))


a, b = -1.994, 1.4
# nro de subintervalos, n/2 é o nro de parabolas, n+1 é o nro de pontos na partição
n = [4, 16, 46, 68, 80, 120, 138, 172, 176, 208, 426]
for ni in n:
    i1 = simps(f, a, b, ni)
    print(i1)


def g(x):
    return math.cos(x ** 2)


x = [0.184, 0.541, 0.898, 0.9085, 0.919, 0.983, 1.047, 1.1165, 1.186, 1.452, 1.718, 1.8175, 1.917, 1.9455, 1.974, 1.9915, 2.009, 2.0955, 2.182, 2.198, 2.214, 2.222,
     2.23, 2.266, 2.302, 2.37, 2.438, 2.5875, 2.737, 2.802, 2.867, 2.904, 2.941, 2.992, 3.043, 3.0705, 3.098, 3.367, 3.636, 3.9165, 4.197, 4.4195, 4.642, 4.6555, 4.669]
y = [1.844, 2.848, 2.937, 2.929, 2.92, 2.859, 2.788, 2.704, 2.615, 2.296, 2.079, 2.033, 2.007, 2.003, 2.001, 2.0, 2.0, 2.009, 2.033, 2.039, 2.046, 2.049,
     2.053, 2.071, 2.091, 2.136, 2.191, 2.338, 2.517, 2.6, 2.683, 2.729, 2.774, 2.833, 2.886, 2.911, 2.934, 2.956, 2.449, 1.493, 1.007, 1.584, 2.642, 2.695, 2.745]
soma = 0
xy = zip(x, y)

for n in range(2, len(x), 2):  # lista de x e y removidos os primeiros elementos
    # print(n, x[n-2], x[n-1], x[n])
    soma += ((x[n-1] - x[n-2])/3) * (y[n-2] + 4*y[n-1] + y[n])

print(soma)
