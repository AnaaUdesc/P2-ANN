# requer número impar de pontos
import math


def simps(f, a, b, n):
    h = (b - a) / n
    soma_impar = sum([f(a + k * h) for k in range(1, n, 2)])
    soma_par = sum([f(a + k * h) for k in range(2, n, 2)])
    return (h/3) * (f(a) + 4 * soma_impar + 2 * soma_par + f(b))


def f(x):
    return math.sqrt(1 + (math.cos(x)**2))


a, b = 1.193, 2.536
# nro de subintervalos, n/2 é o nro de parabolas, n+1 é o nro de pontos na partição
n = [4, 16, 46, 68, 80, 120, 138, 172, 176, 208, 426]
for ni in n:
    i1 = simps(f, a, b, ni)
    print(i1)


def g(x):
    return math.cos(x ** 2)


x = [0,
     5,
     10,
     15,
     20,
     25,
     30,
     35,
     40,
     45,
     50,
     55,
     60,
     65,
     70,
     75,
     80,
     85,
     90,
     ]
y = [
    0,
    104,
    232,
    361,
    509,
    676,
    827,
    968,
    1095,
    1205,
    1321,
    1457,
    1628,
    1827,
    2054,
    2309,
    2597,
    2898,
    3201,
]

soma = 0
xy = zip(x, y)

for n in range(2, len(x), 2):  # lista de x e y removidos os primeiros elementos
    print(n, x[n-2], x[n-1], x[n])
    soma += ((x[n-1] - x[n-2])/3) * (y[n-2] + 4*y[n-1] + y[n])

print(soma)
