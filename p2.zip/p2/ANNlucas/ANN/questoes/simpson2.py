# requer número impar de pontos
import math


def simps(f, a, b, n):
    h = (b - a) / n
    soma_impar = sum([f(a + k * h) for k in range(1, n, 2)])
    soma_par = sum([f(a + k * h) for k in range(2, n, 2)])
    return (h/3) * (f(a) + 4 * soma_impar + 2 * soma_par + f(b))


def f(x):
    return math.sqrt(1 + (math.cos(x)**2))


a, b = 1.193, 2.536
# nro de subintervalos, n/2 é o nro de parabolas, n+1 é o nro de pontos na partição
n = [4, 16, 46, 68, 80, 120, 138, 172, 176, 208, 426]
for ni in n:
    i1 = simps(f, a, b, ni)
    print(i1)


def g(x):
    return math.cos(x ** 2)


x = [0.628, 0.666, 0.704, 0.7935, 0.883, 0.8835, 0.884, 0.938, 0.992, 0.9985, 1.005, 1.045, 1.085, 1.1275, 1.17, 1.2, 1.23, 1.276, 1.322, 1.382, 1.442, 1.7255, 2.009,
     2.319, 2.629, 2.7105, 2.792, 2.8325, 2.873, 2.8945, 2.916, 3.015, 3.114, 3.1445, 3.175, 3.2445, 3.314, 3.3925, 3.471, 3.9815, 4.492, 4.5135, 4.535, 4.576, 4.617]
y = [2.952, 2.978, 2.994, 2.993, 2.948, 2.948, 2.948, 2.903, 2.85, 2.843, 2.836, 2.791, 2.743, 2.69, 2.636, 2.597, 2.559, 2.5, 2.444, 2.373, 2.306, 2.075,
     2.0, 2.102, 2.385, 2.484, 2.587, 2.639, 2.69, 2.717, 2.744, 2.857, 2.946, 2.966, 2.982, 3.0, 2.988, 2.933, 2.829, 1.293, 1.927, 2.034, 2.143, 2.345, 2.536]

soma = 0
xy = zip(x, y)

for n in range(2, len(x), 2):  # lista de x e y removidos os primeiros elementos
    print(n, x[n-2], x[n-1], x[n])
    soma += ((x[n-1] - x[n-2])/3) * (y[n-2] + 4*y[n-1] + y[n])

print(soma)
