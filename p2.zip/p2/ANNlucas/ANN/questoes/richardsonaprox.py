from cmath import cos, e
import math


def richardson(col1):
    col1 = [item for item in col1]
    n = len(col1)
    for j in range(n - 1):
        temp_col = [0] * (n-1-j)
        for i in range(n - 1 - j):
            power = j + 1
            temp_col[i] = (2 ** power * col1[i+1] - col1[i]) / (2 ** power - 1)
        col1[:n - 1 - j] = temp_col
        print(temp_col)
    return col1[0]


def func(x):
    return (pow((math.sin(x), 4)) - (4 * (math.sin(x)**2)) + (math.cos(x)**2) + (pow(math.e, -(x**2)))) + 5


if __name__ == '__main__':

    x0 = 0.40863
    approximations = [-2.6477049181669337, -3.114349513072902, -
                      3.323232487497407, -3.421013745787775, -3.4681929184466185, -3.491350277699098]
    aprox = richardson(approximations)

    print(f'{aprox = }')
