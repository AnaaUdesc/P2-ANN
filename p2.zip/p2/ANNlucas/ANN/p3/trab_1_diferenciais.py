import matplotlib.pyplot as plt
import numpy as np


def euler(f, x0, y0, h, n):
    vals = []
    for k in range(n):
        x0 += h
        y0 += h * f(x0, y0)
        vals.append([x0, y0])
        print(f'x_{k+1} = {x0}, y_{k+1} = {y0}')
    return vals


if __name__ == '__main__':

    def f(x, y):
        return y * (2 - x) + x + 1

    x0 = 0.81619
    y0 = 1.81343
    h = 0.19642
    n = 10  # na questao k = n
    # vals = euler(f, x0, y0, h, n)
    # x_, y_ = zip(*vals)

    for i in range(n):
        yk = y0 + h * f(x0, y0)
        print(f'y_{i+1} = {yk}')
        y0 = yk
        x0 = x0 + h

    # def y(x):
    #     return 3 * np.exp(x/2) - 2

    # t = np.linspace(x0, x0 + n * h, 10)
    # yt = [y(ti) for ti in t]

    # print(yt)
    # plt.plot(t, yt, color="blue")
    # plt.scatter(x_, y_)
    # plt.show()
