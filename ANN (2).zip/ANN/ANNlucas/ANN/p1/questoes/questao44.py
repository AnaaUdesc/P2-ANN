import numpy as np
from math import cos, sin, pi

np.set_printoptions(suppress=True)

alpha = 30*pi/180
beta = 25*pi/180
f4 = 749
f5 = 1007
f6 = 1396
theta1 = 74*pi/180
theta2 = 79*pi/180
theta3 = 48*pi/180

# no 1
# F_h = -F1*cos(alpha) + F3*cos(beta) + F1h + f4*cos(theta1)
# F_v = -F1*sin(alpha) - F3*sin(beta) + F1v

# # no 2
# F_h = F2 + F1*cos(alpha) + F2h + H2 + f5*cos(theta2)
# F_v = F1*sin(alpha) + F2v + V2

# # no 3
# F_h = -F2 - F3*cos(beta) + F3h * f6*cos(theta3)
# F_v = F3*sin(beta) + F3v + V3

f1 = 0
f2 = 0
f3 = 0
h2 = 0
v2 = 0
v3 = 0
f1h = '0, 0, 0'
f1v = '0, 0, 0'
f2h = '-1, 0, 0'
f2v = '0, -1, 0'
f3h = '0, 0, 0'
f3v = '0, 0, -1'

# noXFh = f'[{f1}, {f2}, {f3}, {f4}, {f5}, {f6}, {h2}, {v2}, {v3}]'

# no1Fh = f'[{cos(alpha)}, {0}, {-cos(beta)}, {f4*cos(theta1)}, {0}, {0}, {f1h}]'
# no1Fv = f'[{sin(alpha)}, {0}, {sin(beta)}, {f4*sin(theta1)}, {0}, {0}, {f1v}]'

# no2Fh = f'[{-cos(alpha)}, {-1}, {0}, {0}, {f5*cos(theta2)}, {0}, {f2h}]'
# no2Fv = f'[{-sin(alpha)}, {0}, {0}, {-f4*sin(theta1)}, {f5*sin(theta2)}, {0}, {f2v}]'

# no3Fh = f'[{0}, {1}, {cos(beta)}, {0}, {0}, {f6*cos(theta3)}, {f3h}]'
# no3Fv = f'[{0}, {0}, {-sin(beta)}, {-f4*sin(theta1)}, {0}, {f6*sin(theta3)}, {f3v}]'

# 1

noXFh = [f1, f2, f3, f4, f5, f6, h2, v2, v3]

# com 9
# no1Fh = [cos(alpha), 0, -cos(beta), f4*cos(theta1), 0, 0, 0, 0, 0]
# no1Fv = [sin(alpha), 0, sin(beta), f4*sin(theta1), 0, 0, 0, 0, 0]

# no2Fh = [-cos(alpha), -1, 0, 0, f5*cos(theta2), 0, -1, 0, 0]
# no2Fv = [-sin(alpha), 0, 0, -f4*sin(theta1), f5*sin(theta2), 0, 0, -1, 0]

# no3Fh = [0, 1, cos(beta), 0, 0, f6*cos(theta3), 0, 0, 0]
# no3Fv = [0, 0, -sin(beta), -f4*sin(theta1), 0, f6*sin(theta3), 0, 0, -1]

# com 6
no1Fh = [cos(alpha), 0, -cos(beta), 0, 0, 0]
no1Fv = [sin(alpha), 0, sin(beta), 0, 0, 0]

no2Fh = [-cos(alpha), -1, 0, -1, 0, 0]
no2Fv = [-sin(alpha), 0, 0, 0, -1, 0]

no3Fh = [0, 1, cos(beta), 0, 0, 0]
no3Fv = [0, 0, -sin(beta), 0, 0, -1]

# no1Fh = f'[{cos(alpha)}, {0}, {-cos(beta)}, {0}, {0}, {0}]'
# no1Fv = f'[{sin(alpha)}, {0}, {sin(beta)}, {0}, {0}, {0}]'

# no2Fh = f'[{-cos(alpha)}, {-1}, {0}, {-1}, {0}, {0}]'
# no2Fv = f'[{-sin(alpha)}, {0}, {0}, {0}, {-1}, {0}]'

# no3Fh = f'[{0}, {1}, {cos(beta)},{0}, {0}, {0}]'
# no3Fv = f'[{0}, {0}, {-sin(beta)}, {0}, {0}, {-1}]'

# ixj = 6x9

# A = np.array([
#     eval(no1Fh),
#     eval(no1Fv),
#     eval(no2Fh),
#     eval(no2Fv),
#     eval(no3Fh),
#     eval(no3Fv)
# ])

A = np.array([
    no1Fh,
    no1Fv,
    no2Fh,
    no2Fv,
    no3Fh,
    no3Fv
])

X = np.array([f1, f2, f3, h2, v2, v3])
B = np.array([0,
              0,
              0,
              -f4*sin(theta1),
              -f5*sin(theta2),
              -f6*sin(theta3),
              0,
              0,
              0,
              ])

print('A = \n', A)
print('A^-1 = \n', np.linalg.inv(A))
print('B = \n', B)
# X = np.array([f1, f2, f3, h2, v2, v3])
# B = np.array([0, 0, 0, -f4, -f5, -f6, 0, 0, 0])
# print('resposta =\n', np.linalg.solve(A, B))

# esperado:
# -903.10287603307
# -358.44867310847
# -635.16794360856
# 948.41404763972
# 1440.0500117483
# 1305.8637486077


# 0.866025	0.000000	-0.906308	0.000000	0.000000	0.000000
# 0.000000	-1.000000	-0.906308	-1.000000	0.000000	0.000000
# 0.000000	0.000000	0.945875	0.000000	0.000000	0.000000
# 0.000000	0.000000	0.000000	-1.000000	0.000000	0.000000
# 0.000000	0.000000	0.000000	0.000000	-1.000000	0.000000
# 0.000000	0.000000	0.000000	0.000000	0.000000	-1.000000
