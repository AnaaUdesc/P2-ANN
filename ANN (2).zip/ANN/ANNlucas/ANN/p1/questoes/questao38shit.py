
k1 = 537
k2 = 603
k3 = 269
k4 = 232
k3 = 694
k5 = 694
k6 = 634
k7 = 259
k8 = 290

x1 = 'x1'
x2 = 'x2'
x3 = 'x3'
x4 = 'x4'

print(f'{x4} + {k8} = {x3} + {k7}')
print(f'{x3} + {k6} = {x2} + {k5}')
print(f'{x1} + {k2} = {x4} + {k1}')
print(f'{x2} + {k4} = {x1} + {k3}')

print()

print(f'{x4} - {x3} = {k7 - k8}')
print(f'{x3} - {x2} = {k5 - k6}')
print(f'{x1} - {x4} = {k1 - k2}')
print(f'{x2} - {x1} = {k3 - k4}')

print()


# x1 = 1
# x2 = 1
# x3 = 1
# x4 = 1

# print(f'[{0}, {0}, -{x3}, {x4}]')
# print(f'[{0}, -{x2}, {x3}, {0}]')
# print(f'[{x1}, {0}, {0}, -{x4}]')
# print(f'[-{x1}, {x2}, {0}, {0}]')

# X = [k7 - k8,
#      k5 - k6,
#      k1 - k2,
#      k3 - k4]

# print(X)
