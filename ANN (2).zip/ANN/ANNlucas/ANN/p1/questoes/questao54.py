def lagrange(x, y):
    # retorna yi dividido pelo denominador do polinomio Li
    num = len(x)
    coefs = []
    for i in range(num):
        prod = 1
        for j in range(num):
            if i != j:
                prod *= (x[i] - x[j])
        ci = y[i]/prod
        coefs.append(ci)
    return coefs


def pl(t, x, coefs):
    soma = 0
    num = len(coefs)
    for i in range(num):
        prod = 1
        for j in range(num):
            if i != j:
                prod *= (t-x[j])
        prod *= coefs[i]
        soma += prod
    return soma


def poly(x, coefs):
    def f(t):
        return pl(t, x, coefs)
    return f


if __name__ == '__main__':
    x = [-1.815, -0.429, 1.097, 1.977, 3.114, 3.949, 5.692, 6.312]
    y = [0.569, 0.968, 0.871, 0.467, -0.427, -0.927, -0.316, 0.27]

    # x=[-0.691, 0.247, 0.681]
    # y=[0.07729752396, 0.39600431644 ,0.07940273264]

    # x=[1,3]
    # y=[1,-1]

    c = lagrange(x, y)
    print(c)
    lagr = poly(x, c)
    # print(lagrange(x, y))
    print(lagr(0))

    import matplotlib.pyplot as plt
    import numpy as np

    np.set_printoptions(suppress=True)
    plt.scatter(x, y)
    t = np.linspace(min(x), max(x), 100)
    lt = [lagr(ti) for ti in t]
    plt.plot(t, lt)
    plt.show()
