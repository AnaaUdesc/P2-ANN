import matplotlib.pyplot as plt
import numpy as np
import math


def coeffs_dif_fin(x0, x, y, k):
    n - len(x)
    A, B = [[1] * n], [0]
    for i in range(1, n):
        # construção da matriz A
        row_i = [xi ** i for xi in x]
        A.append(row_i)
        # construção da matriz B
        if i < k:
            B.append(0)
        elif i == k:
            B.append(math.factorial(k))
        else:
            numer = math.factorial(i)
            denom = math.factorial(i-k)
            el = (numer/denom) * x0 ** (i - k)
            B.append(el)

    A = np.array(A, dtype=float)
    B = np.array(B, dtype=float)
    return np.linalg.solve(A, B)


def dif_fin(coeffs, y):
    return sum


if __name__ == '__main__':
    # exemplo1
    def f(x):
        return x ** x
    x0 = 2
    k = 1
    e = 0.1

    # queremos pontos no intervalo (x0-e, x0+e)
    # h = 2 * e
    n = 10
    # x = [x0 - e + i * h / 10 for i in range(n)]
    x = np.linspace(x0-e, x0+e, n)

    y = [f(xi) for xi in x]

    coeffs = coeffs_dif_fin(x0, x, y, k)
    aprox = dif_fin(coeffs, y)

    print(f'coeffs: {coeffs}')
    print(f'aprox: {aprox}')
