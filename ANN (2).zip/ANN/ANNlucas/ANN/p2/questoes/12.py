import numpy as np


def best_poly(x, y, grau=1):
    k = grau + 1
    A = [[0 for _ in range(k)] for _ in range(k)]
    B = [sum(y)]
    n = len(x)
    cache = {}
    for i in range(k):
        for j in range(k):
            p = i + j
            if (p == 0):
                A[0][0] = n
                continue
            if p not in cache:
                cache[p] = sum([xi ** p for xi in x])
            A[i][j] = cache[p]
        if i > 0:
            B.append(sum([yi * xi ** i for xi, yi in zip(x, y)]))
    return np.linalg.solve(A, B)


def poly(x, a, b):
    return a * 2 ** (b * x)


def build_func(a, b):
    def temp(x):
        return poly(x, a, b)
    return temp


if __name__ == '__main__':
    x = [0.3995, 0.97, 2.0343, 2.7567, 3.9472, 4.8679,
         5.1749, 6.0818, 7.238, 7.8686, 8.9499, 9.7128]
    y = [4.9393, 4.6405, 4.1364, 3.7495, 3.3321, 3.2177,
         3.2578, 3.4545, 3.5728, 3.8718, 4.6922, 5.1904]
    x_values = [2.4218, 6.6672, 7.1633]
    y_ = np.log(y)

    grau = 1

    a0, a1 = best_poly(x, y_, grau)

    print(f'{a0 = } e {a1 = }')

    a = np.exp(a0)
    b = a1/np.log(2)

    print(f'{a = } e {b = }')

    p = build_func(a, b)

    # x_values =  [0.4147, 0.8501, 1.5436, 1.7388, 1.7819]

    for xi_v in x_values:
        print(p(xi_v))
