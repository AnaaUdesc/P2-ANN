'''
Em um circuito com tensão aplicada E e com resistência R, indutância L e capacitância C em paralelo, a corrente i satisfaz a equação diferencial
didt=Cd2Edt2+1RdEdt+1LE.
Suponha que C=0.384farads, R=1.4601ohm, L=1.7764henrie e que a tensão seja dada por
E(t)=e−0.0602πtsin(2t−π).
Se i(t0)=i0, com t0=0 e i0=0, use o método de Ralston para encontrar estimativas
para a corrente i nos pontos tk=t0+kh, onde k=1,2,…,150 e h=0.0715.

'''


import numpy as np
import matplotlib.pyplot as plt


def rk2(f, x0, y0, h, n, b=1.0):
    # b = 1 => metodo = euler_mid
    # b = 1/2 => metodo = heun
    # b = 2/3 => metodo = ralston
    vals = []
    a = 1-b
    p = 1/(2*b)
    q = p
    for _ in range(n):
        m1 = f(x0, y0)
        m2 = f(x0 + p*h, y0 + q*h*m1)
        y0 += (a*m1 + b*m2)*h
        x0 += h
        vals.append([x0, y0])
    return vals


def g(t, i):
    c = 0.2471
    r = 1.2985
    l = 1.7742

    # considerando a função e(t) = e^(-e_value*pi*t)*sin(2*t-pi)
    # se e^(-0.0619*pi*t) => e_value = 0.0619
    e_value = 0.0715

    def e(t):
        return np.exp(-e_value*np.pi*t) * np.sin(2*t-np.pi)

    def e_(t):
        return np.exp(-e_value*np.pi*t) * (2 * np.cos(np.pi-2*t) + e_value*np.pi*np.sin(np.pi-2*t))

    def e__(t):
        return np.exp(-e_value*np.pi*t)*((4-pow(e_value, 2)*pow(np.pi, 2))*np.sin(np.pi-2*t)-4*e_value*np.pi*np.cos(np.pi-2*t))

    return c * e__(t) + (1/r) * e_(t) + (1/l) * e(t)


if __name__ == '__main__':

    x0, y0 = 0,0 # i0, t0
    h = 0.0756 # h
    n = 150 # k
    b = 2/3 #

    metodo5 = rk2(g, x0, y0, h, n, b)

    indice = [i for i in range(n)]
    lista_x, lista_y = zip(*metodo5)

    for i, xi, yi in zip(indice, lista_x, lista_y):
        #print(f'x{i} = {xi} => y{i} = {yi}')
        print(f'{yi},', end='')

    # plt.scatter(lista_x, lista_y)

    # plt.show()
