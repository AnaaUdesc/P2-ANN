import matplotlib.pyplot as plt
import numpy as np


def euler(f, x0, y0, h, n):
    vals = []
    for k in range(n):
        x0 += h
        y0 += h * f(x0, y0)
        vals.append([x0, y0])
    return vals


if __name__ == '__main__':

    def f(x, y):
        return y / 2 + 1

    x0 = 0
    y0 = 1
    h = 0.125
    n = 100
    vals = euler(f, x0, y0, h, n)
    x_, y_ = zip(*vals)

    def y(x):
        return 3 * np.exp(x/2) - 2

    t = np.linspace(x0, x0 + n * h, 200)
    yt = [y(ti) for ti in t]
    plt.plot(t, yt, color="blue")
    plt.scatter(x_, y_)
    plt.show()
