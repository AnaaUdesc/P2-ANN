
import math

#   INTEGRAIS
#           REGRA DOS TRAPEZIOS
# Entrada: funcao f, ponto a, ponto b, numPontosParticao


def trapezio(f, a, b, n):
    h = (b - a) / n
    soma = 0
    for k in range(1, n):  # comecar em 1 evitando que o primeiro ponto seja calculado 2 vezes
        soma += f(a + k * h)
    soma *= 2
    soma += (f(a) + f(b))
    soma *= (h / 2)
    return soma


def f(x):
    return (9 + 4*pow(math.cos(0.21*x), 2)) * (5*pow(math.e, -0.48*x) + 2*pow(math.e, 0.17*x))


a, b = 1.67, 8.09
subintervalos = 19

if __name__ == "__main__":
    # print(trapezio(f,a,b,n))
    sum = 0.0
    for i in range(subintervalos):
        print(trapezio(f, a, b, subintervalos))
    # x = [1.187, 1.818, 2.338, 2.977, 2.986, 4.489, 4.565]
    # y = [2.614, 2.033, 2.114, 2.816, 2.826, 1.912, 2.292]
    # for i in range(len(x)-1):
    #     sum += trapezio(f, x[i], x[i+1], subintervalos)
    # for i in range(len(x)):
    #     print(x[i], y[i])
    print(sum)
