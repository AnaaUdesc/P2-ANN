#include<stdio.h>

int main(){


}

def lagrange(x,y);