import numpy as np
import math 

def dif_div(x, y):
    Y = [yi for yi in y]
    coefs = [y[0]]
    for j in range(len(x)-1):
        for i in range(len(x)-1-j):
            number = Y[i+1]-Y[i]
            denom = x[i+1+j]-x[i]
            div = number/denom
            Y[i] = div
        coefs.append(Y[0])
    return coefs


def poly(t, x, coefs):
    val = 0
    for i in range(len(coefs)):
        prod = 1
        for j in range(i):
            prod *= (t-x[j])
        val += coefs[i]*prod
    return val


def build_func(x, coefs):
    def temp(t):
        return poly(t, x, coefs)
    return temp


if __name__ == '__main__':
    x = [-0.408, -0.301, -0.206, -0.149, -0.048, 0.086, 0.171, 0.277, 0.377, 0.54, 0.604, 0.746, 0.829, 0.908, 1.015, 1.165, 1.214, 1.343, 1.43]
    y = []

    def f(x):
        #return np.cos(np.sin(np.log(x**2)))
        return math.pow(x,5)-4*pow(x,2)+2*math.sqrt(x+1)+np.cos(x)

    for i in x:
        y.append(f(i))

    coefs = dif_div(x, y)
    p = build_func(x, coefs)
    print(coefs)