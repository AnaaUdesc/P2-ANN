import math
import numpy as np

def lagrange(x, y):
    for i in range(len(x)):
        a = 1
        for j in range(len(x)):
            if i != j:
                a *= (x[i]-x[j])
        print(y[i]/a, ",")


if __name__ == '__main__':
    # x = [-1.823, -0.45, 0.724, 1.497, 2.787, 3.853, 5.34, 6.035]  # coordenadas x do ponto
    # y = [0.564, 0.967, 0.941, 0.732, -0.161, -0.891, -0.611, 0.007]  # coordenadas y do ponto

    x = []
    y = []
    z = [1.55, 1.601, 1.833, 1.96, 2.118, 2.407, 2.506, 2.736, 2.845, 3.069, 3.172, 3.356, 3.488, 3.78, 3.855, 4.065, 4.215, 4.385, 4.509, 4.782, 4.972]

    def f(x):
        return math.cos(x + math.sqrt(math.log(x**2)))

    for i in z:
        x.append(i)
        y.append(f(i))

    lagrange(x, y)