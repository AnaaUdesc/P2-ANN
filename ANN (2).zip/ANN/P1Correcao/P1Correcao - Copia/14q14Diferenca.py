import numpy as np
import math 

def dif_div(x, y):
    Y = [yi for yi in y]
    coefs = [y[0]]
    for j in range(len(x)-1):
        for i in range(len(x)-1-j):
            number = Y[i+1]-Y[i]
            denom = x[i+1+j]-x[i]
            div = number/denom
            Y[i] = div
        coefs.append(Y[0])
    return coefs


def poly(t, x, coefs):
    val = 0
    for i in range(len(coefs)):
        prod = 1
        for j in range(i):
            prod *= (t-x[j])
        val += coefs[i]*prod
    return val


def build_func(x, coefs):
    def temp(t):
        return poly(t, x, coefs)
    return temp


if __name__ == '__main__':
    x = [-0.452, -0.302, -0.239, -0.149, -0.037, 0.103, 0.171, 0.277, 0.428, 0.474, 0.573, 0.7, 0.783, 0.953, 1.018, 1.091, 1.221, 1.373, 1.435]
    y = []

    def f(x):
        #return np.cos(np.sin(np.log(x**2)))
        return math.pow(x,5)-4*pow(x,2)+2*math.sqrt(x+1)+np.cos(x)

    for i in x:
        y.append(f(i))

    coefs = dif_div(x, y)
    p = build_func(x, coefs)
    print(coefs)